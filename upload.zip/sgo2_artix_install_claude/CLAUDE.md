# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is a **system configuration and installation planning project** for setting up a Microsoft Surface Go 2 with Artix Linux. It is not a traditional software project—there is no code to build, test, or run. The main artifact is `plan.md`, which serves as a comprehensive blueprint for system setup.

## Project Structure

```
sgo2_artix_install_claude/
├── install.sh              # Main installation script (run from live USB)
├── chroot-setup.sh         # Script executed inside chroot environment
├── lib/
│   ├── common.sh           # Shared utility functions (colors, prompts, logging)
│   ├── disk.sh             # Disk partitioning functions
│   ├── encryption.sh       # LUKS encryption and keyfile setup
│   ├── base.sh             # Base system installation (basestrap)
│   ├── chroot.sh           # Chroot configuration functions
│   ├── packages.sh         # Package installation from Artix repos
│   └── surface.sh          # Microsoft Surface-specific setup
├── config/
│   └── packages.conf       # Package lists by category
├── plan.md                 # Hardware specs and software requirements
└── wallpaper_motorcycle_bmw_s1000rr.jpg
```

## Target System Configuration

- **Hardware**: Microsoft Surface Go 2 (Pentium Gold 4425Y, 4GB RAM, 64GB eMMC)
- **OS**: Artix Linux (systemd-free, runit-based)
- **Kernel**: linux-surface (optimized for Surface devices)
- **Display**: Wayland-only (no X11)
- **Window Manager**: Hyprland
- **Init System**: runit
- **Shell**: zsh (default) + nushell

## Key Constraints

- **No X11**: All software must be Wayland-native or Wayland-compatible
- **Artix repos only**: Avoid Arch repos unless absolutely necessary
- **Resource-conscious**: 4GB RAM and limited storage require lightweight alternatives
- **Full disk encryption**: LUKS2 with SD card keyfile (TPM2 can be added post-install)

## Running the Installation

From an Artix Linux live USB on the Surface Go 2:

```bash
# Make executable
chmod +x install.sh chroot-setup.sh

# Run installation (fully interactive)
./install.sh

# Or dry-run mode to preview actions
./install.sh --dry-run
```

The installer handles:
1. Disk partitioning (EFI + LUKS-encrypted root)
2. SD card keyfile generation for auto-unlock
3. Base system installation via `basestrap`
4. linux-surface kernel from linux-surface repo
5. Hyprland and Wayland packages from Artix repos
6. Generates `post-install-aur.md` for packages requiring AUR

## Working with plan.md

The document is organized into sections:
1. **Hardware** - Device specifications
2. **Core Software** - Essential system tools (shells, editors, network, AI clients, etc.)
3. **Environment** - Desktop components (Hyprland, Foot terminal, launchers, etc.)
4. **Misc. Requirements** - Security and compatibility constraints
5. **Integrations/Scripts** - Planned automation and workflow integrations
6. **Rice** - Theming (Vaporwave theme planned)
7. **Configs** - Placeholder for configuration file locations (incomplete)

## Incomplete Sections

The following areas in `plan.md` are marked for future completion:
- SMS/MMS/RCS messenger solution (marked "tbd")
- Cargo/Rust dev packages reference
- Config files list and locations

## Modifying Package Lists

Edit `config/packages.conf` to add/remove packages. Categories:
- `[development]` - Languages and dev tools
- `[terminal]` - Shell and CLI utilities
- `[wayland]` - Desktop environment
- `[applications]` - GUI apps
- `[utilities]` - System utilities
- `[audio]` - PipeWire audio stack
- `[bluetooth]` - Bluetooth support
- `[power]` - TLP power management
- `[tty]` - TTY utilities (gpm)
