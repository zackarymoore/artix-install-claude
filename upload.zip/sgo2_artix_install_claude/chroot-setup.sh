#!/bin/bash
# chroot-setup.sh - Script to run inside chroot environment
#
# This script is executed via artix-chroot during installation.
# It performs configuration tasks that require the chroot environment.

set -euo pipefail

# =============================================================================
# COLORS
# =============================================================================
readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly CYAN='\033[0;36m'
readonly NC='\033[0m'

# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

info()    { echo -e "${CYAN}[INFO]${NC} $*"; }
success() { echo -e "${GREEN}[SUCCESS]${NC} $*"; }
warn()    { echo -e "${YELLOW}[WARNING]${NC} $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*" >&2; }

section() {
    echo
    echo -e "${CYAN}════════════════════════════════════════════════════════════════${NC}"
    echo -e "  $1"
    echo -e "${CYAN}════════════════════════════════════════════════════════════════${NC}"
    echo
}

# =============================================================================
# CONFIGURATION VARIABLES
# =============================================================================

# These can be overridden by environment variables
USERNAME="${USERNAME:-user}"
TIMEZONE="${TIMEZONE:-America/Los_Angeles}"
LOCALE="${LOCALE:-en_US.UTF-8}"
HOSTNAME="${HOSTNAME:-surface-go}"

# =============================================================================
# LOCALE CONFIGURATION
# =============================================================================

configure_locale() {
    section "Locale Configuration"

    info "Setting locale to ${LOCALE}..."

    # Uncomment locale in locale.gen
    sed -i "s/^#${LOCALE}/${LOCALE}/" /etc/locale.gen
    sed -i "s/^#en_US.UTF-8/en_US.UTF-8/" /etc/locale.gen

    # Generate locales
    locale-gen

    # Set system locale
    echo "LANG=${LOCALE}" > /etc/locale.conf

    # Console keymap
    echo "KEYMAP=us" > /etc/vconsole.conf

    success "Locale configured"
}

# =============================================================================
# TIMEZONE CONFIGURATION
# =============================================================================

configure_timezone() {
    section "Timezone Configuration"

    info "Setting timezone to ${TIMEZONE}..."

    ln -sf "/usr/share/zoneinfo/${TIMEZONE}" /etc/localtime
    hwclock --systohc

    success "Timezone configured"
}

# =============================================================================
# HOSTNAME CONFIGURATION
# =============================================================================

configure_hostname() {
    section "Hostname Configuration"

    info "Setting hostname to ${HOSTNAME}..."

    echo "$HOSTNAME" > /etc/hostname

    cat > /etc/hosts << EOF
# Static table lookup for hostnames.
127.0.0.1       localhost
::1             localhost
127.0.1.1       ${HOSTNAME}.localdomain ${HOSTNAME}
EOF

    success "Hostname configured"
}

# =============================================================================
# USER CREATION
# =============================================================================

create_user() {
    section "User Creation"

    info "Creating user ${USERNAME}..."

    # Check if user exists
    if id "$USERNAME" &>/dev/null; then
        warn "User $USERNAME already exists"
    else
        useradd -m -G wheel,audio,video,input,storage,optical -s /bin/bash "$USERNAME"
        info "User created"
    fi

    # Set passwords
    info "Set password for ${USERNAME}:"
    passwd "$USERNAME"

    info "Set root password:"
    passwd root

    # Enable sudo for wheel group
    sed -i 's/^# %wheel ALL=(ALL:ALL) ALL/%wheel ALL=(ALL:ALL) ALL/' /etc/sudoers

    success "User configured"
}

# =============================================================================
# PACMAN CONFIGURATION
# =============================================================================

configure_pacman() {
    section "Pacman Configuration"

    info "Configuring pacman..."

    local pacman_conf="/etc/pacman.conf"

    # Enable features
    sed -i 's/^#Color/Color/' "$pacman_conf"
    sed -i 's/^#ParallelDownloads = 5/ParallelDownloads = 5/' "$pacman_conf"
    sed -i 's/^#VerbosePkgLists/VerbosePkgLists/' "$pacman_conf"

    success "Pacman configured"
}

# =============================================================================
# LINUX-SURFACE REPOSITORY
# =============================================================================

add_surface_repo() {
    section "Linux-Surface Repository"

    info "Adding linux-surface repository..."

    # Import key
    curl -s https://raw.githubusercontent.com/linux-surface/linux-surface/master/pkg/keys/surface.asc | pacman-key --add -
    pacman-key --finger 56C464BAAC421453
    pacman-key --lsign-key 56C464BAAC421453

    # Add repo to pacman.conf
    if ! grep -q "linux-surface" /etc/pacman.conf; then
        cat >> /etc/pacman.conf << 'EOF'

# Linux Surface kernel repository
[linux-surface]
Server = https://pkg.surfacelinux.com/arch/
EOF
    fi

    # Sync repos
    pacman -Sy

    success "Linux-surface repository added"
}

# =============================================================================
# SURFACE KERNEL INSTALLATION
# =============================================================================

install_surface_kernel() {
    section "Surface Kernel Installation"

    info "Installing linux-surface kernel..."

    pacman -S --noconfirm linux-surface linux-surface-headers iptsd

    success "Linux-surface kernel installed"
}

# =============================================================================
# MKINITCPIO CONFIGURATION
# =============================================================================

configure_mkinitcpio() {
    section "Mkinitcpio Configuration"

    info "Configuring mkinitcpio for LUKS..."

    local conf="/etc/mkinitcpio.conf"

    # Add keyfile to FILES
    if ! grep -q "crypto_keyfile.bin" "$conf"; then
        sed -i 's|^FILES=(|FILES=(/crypto_keyfile.bin |' "$conf"
    fi

    # Configure HOOKS for encryption
    sed -i 's|^HOOKS=.*|HOOKS=(base udev autodetect modconf kms keyboard keymap consolefont block encrypt filesystems fsck)|' "$conf"

    # Regenerate initramfs
    info "Regenerating initramfs..."
    mkinitcpio -P

    success "Mkinitcpio configured"
}

# =============================================================================
# GRUB INSTALLATION
# =============================================================================

install_grub() {
    section "GRUB Installation"

    info "Installing GRUB bootloader..."

    # Install GRUB
    grub-install --target=x86_64-efi --efi-directory=/boot/efi --bootloader-id=ARTIX --recheck

    # Generate config
    grub-mkconfig -o /boot/grub/grub.cfg

    success "GRUB installed"
}

# =============================================================================
# SERVICE CONFIGURATION
# =============================================================================

enable_services() {
    section "Service Configuration"

    info "Enabling services..."

    local services=(
        "NetworkManager"
        "bluetoothd"
        "elogind"
        "tlp"
    )

    for service in "${services[@]}"; do
        local sv_path="/etc/runit/sv/${service}"
        local runsvdir="/etc/runit/runsvdir/default"

        if [[ -d "$sv_path" ]]; then
            ln -sf "$sv_path" "$runsvdir/" 2>/dev/null || true
            info "Enabled: $service"
        else
            warn "Service not found: $service"
        fi
    done

    success "Services enabled"
}

# =============================================================================
# SHELL SETUP
# =============================================================================

setup_shell() {
    section "Shell Configuration"

    info "Installing and configuring zsh..."

    # Install zsh packages
    pacman -S --noconfirm --needed zsh zsh-completions zsh-autosuggestions zsh-syntax-highlighting

    # Change shell for user
    chsh -s /bin/zsh "$USERNAME"

    success "Shell configured"
}

# =============================================================================
# ENVIRONMENT CONFIGURATION
# =============================================================================

configure_environment() {
    section "Environment Configuration"

    info "Setting up environment variables..."

    # System-wide environment
    cat > /etc/environment << 'EOF'
# System-wide environment variables

# Wayland
MOZ_ENABLE_WAYLAND=1
QT_QPA_PLATFORM=wayland
SDL_VIDEODRIVER=wayland
CLUTTER_BACKEND=wayland
XDG_SESSION_TYPE=wayland

# Editor
EDITOR=nvim
VISUAL=nvim
PAGER=less

# History
HISTSIZE=10000
HISTFILESIZE=20000
EOF

    # XDG directories
    cat > /etc/profile.d/xdg.sh << 'EOF'
#!/bin/sh
export XDG_CONFIG_HOME="${HOME}/.config"
export XDG_CACHE_HOME="${HOME}/.cache"
export XDG_DATA_HOME="${HOME}/.local/share"
export XDG_STATE_HOME="${HOME}/.local/state"
export XDG_RUNTIME_DIR="/run/user/$(id -u)"
EOF
    chmod +x /etc/profile.d/xdg.sh

    success "Environment configured"
}

# =============================================================================
# MAIN
# =============================================================================

main() {
    section "Chroot Setup Script"

    info "Running chroot configuration..."

    # Run configuration steps
    configure_locale
    configure_timezone
    configure_hostname
    configure_pacman
    add_surface_repo
    install_surface_kernel
    configure_mkinitcpio
    install_grub
    enable_services
    setup_shell
    configure_environment

    success "Chroot setup complete!"
}

# Only run if executed directly (not sourced)
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi
