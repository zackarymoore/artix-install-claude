-- =============================================================================
-- Neovim Options
-- =============================================================================

local opt = vim.opt

-- -----------------------------------------------------------------------------
-- General
-- -----------------------------------------------------------------------------
opt.mouse = "a"                        -- Enable mouse in all modes
opt.clipboard = "unnamedplus"          -- Use system clipboard
opt.swapfile = false                   -- No swap files
opt.backup = false                     -- No backup files
opt.undofile = true                    -- Persistent undo
opt.undodir = vim.fn.stdpath("state") .. "/undo"
opt.updatetime = 200                   -- Faster completion
opt.timeoutlen = 300                   -- Faster key sequence completion
opt.confirm = true                     -- Confirm to save changes
opt.autowrite = true                   -- Auto save before commands

-- -----------------------------------------------------------------------------
-- UI
-- -----------------------------------------------------------------------------
opt.number = true                      -- Line numbers
opt.relativenumber = true              -- Relative line numbers
opt.signcolumn = "yes"                 -- Always show sign column
opt.cursorline = true                  -- Highlight current line
opt.termguicolors = true               -- True color support
opt.showmode = false                   -- Don't show mode (status line does)
opt.showcmd = false                    -- Don't show command
opt.laststatus = 3                     -- Global status line
opt.cmdheight = 1                      -- Command line height
opt.pumheight = 10                     -- Popup menu height
opt.pumblend = 10                      -- Popup menu transparency
opt.winblend = 10                      -- Floating window transparency
opt.scrolloff = 8                      -- Lines to keep above/below cursor
opt.sidescrolloff = 8                  -- Columns to keep left/right of cursor
opt.splitbelow = true                  -- Open horizontal splits below
opt.splitright = true                  -- Open vertical splits to the right
opt.splitkeep = "screen"               -- Keep text on same screen line
opt.fillchars = {
  foldopen = "",
  foldclose = "",
  fold = " ",
  foldsep = " ",
  diff = "╱",
  eob = " ",
}

-- -----------------------------------------------------------------------------
-- Search
-- -----------------------------------------------------------------------------
opt.ignorecase = true                  -- Ignore case in search
opt.smartcase = true                   -- Override ignorecase if uppercase
opt.hlsearch = true                    -- Highlight search results
opt.incsearch = true                   -- Show matches while typing
opt.grepformat = "%f:%l:%c:%m"         -- Grep format
opt.grepprg = "rg --vimgrep"           -- Use ripgrep

-- -----------------------------------------------------------------------------
-- Indentation
-- -----------------------------------------------------------------------------
opt.expandtab = true                   -- Use spaces instead of tabs
opt.shiftwidth = 4                     -- Shift 4 spaces
opt.tabstop = 4                        -- Tab = 4 spaces
opt.softtabstop = 4                    -- Soft tab = 4 spaces
opt.smartindent = true                 -- Smart auto-indent
opt.shiftround = true                  -- Round indent to shiftwidth

-- -----------------------------------------------------------------------------
-- Wrapping
-- -----------------------------------------------------------------------------
opt.wrap = false                       -- Don't wrap lines
opt.linebreak = true                   -- Wrap at word boundaries when wrap enabled
opt.breakindent = true                 -- Indent wrapped lines

-- -----------------------------------------------------------------------------
-- Folding
-- -----------------------------------------------------------------------------
opt.foldmethod = "expr"                -- Use expression for folding
opt.foldexpr = "nvim_treesitter#foldexpr()"
opt.foldenable = false                 -- Disable folding by default
opt.foldlevel = 99                     -- Open all folds by default

-- -----------------------------------------------------------------------------
-- Completion
-- -----------------------------------------------------------------------------
opt.completeopt = "menu,menuone,noselect"
opt.shortmess:append("c")              -- Don't show completion messages

-- -----------------------------------------------------------------------------
-- Format Options
-- -----------------------------------------------------------------------------
opt.formatoptions = "jcroqlnt"         -- tcqj is default

-- -----------------------------------------------------------------------------
-- Spell
-- -----------------------------------------------------------------------------
opt.spelllang = { "en" }
opt.spell = false                      -- Disable by default

-- -----------------------------------------------------------------------------
-- Session
-- -----------------------------------------------------------------------------
opt.sessionoptions = { "buffers", "curdir", "tabpages", "winsize", "help", "globals", "skiprtp", "folds" }

-- -----------------------------------------------------------------------------
-- Disable providers
-- -----------------------------------------------------------------------------
vim.g.loaded_python3_provider = 0
vim.g.loaded_ruby_provider = 0
vim.g.loaded_perl_provider = 0
vim.g.loaded_node_provider = 0
