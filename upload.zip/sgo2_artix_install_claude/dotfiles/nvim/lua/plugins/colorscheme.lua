-- =============================================================================
-- Colorscheme - Selenized Dark
-- =============================================================================

return {
  -- Selenized colorscheme
  {
    "calind/selenized.nvim",
    lazy = false,
    priority = 1000,
    config = function()
      vim.g.selenized_variant = "bw"
      vim.cmd.colorscheme("selenized")
    end,
  },

  -- Alternative: Catppuccin (if selenized not available)
  {
    "catppuccin/nvim",
    name = "catppuccin",
    lazy = true,
    opts = {
      flavour = "mocha",
      transparent_background = false,
      term_colors = true,
      integrations = {
        cmp = true,
        gitsigns = true,
        treesitter = true,
        telescope = true,
        mini = true,
        native_lsp = {
          enabled = true,
          underlines = {
            errors = { "undercurl" },
            hints = { "undercurl" },
            warnings = { "undercurl" },
            information = { "undercurl" },
          },
        },
      },
    },
  },
}
