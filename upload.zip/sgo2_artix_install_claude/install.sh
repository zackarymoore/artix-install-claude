#!/bin/bash
# install.sh - Main installation script for Artix Linux on Surface Go 2
#
# This script is intended to be run from an Artix Linux live USB environment.
# It will guide you through installing Artix Linux with full disk encryption.
#
# Usage:
#   ./install.sh           # Interactive installation
#   ./install.sh --dry-run # Preview actions without making changes
#   ./install.sh --help    # Show help

set -euo pipefail

# =============================================================================
# INITIALIZATION
# =============================================================================

# Determine script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export SCRIPT_DIR

# Source library files
source "${SCRIPT_DIR}/lib/common.sh"
source "${SCRIPT_DIR}/lib/disk.sh"
source "${SCRIPT_DIR}/lib/encryption.sh"
source "${SCRIPT_DIR}/lib/base.sh"
source "${SCRIPT_DIR}/lib/chroot.sh"
source "${SCRIPT_DIR}/lib/packages.sh"
source "${SCRIPT_DIR}/lib/surface.sh"

# =============================================================================
# COMMAND LINE PARSING
# =============================================================================

show_help() {
    cat << EOF
Artix Linux Installation Script for Surface Go 2

Usage: $0 [OPTIONS]

Options:
    --dry-run       Preview actions without making any changes
    --verbose       Enable verbose output
    --help          Show this help message

Description:
    This script installs Artix Linux with:
    - Full disk encryption (LUKS2)
    - Runit init system
    - Linux-surface kernel for Surface hardware support
    - Hyprland Wayland compositor
    - Development environment

Requirements:
    - Artix Linux live USB environment
    - Internet connection
    - Target disk for installation
    - Optional: SD card for keyfile storage

EOF
    exit 0
}

parse_args() {
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --dry-run)
                DRY_RUN=true
                export DRY_RUN
                ;;
            --verbose)
                VERBOSE=true
                export VERBOSE
                ;;
            --help|-h)
                show_help
                ;;
            *)
                error "Unknown option: $1"
                show_help
                ;;
        esac
        shift
    done
}

# =============================================================================
# WELCOME SCREEN
# =============================================================================

show_welcome() {
    clear
    echo -e "${CYAN}"
    cat << 'EOF'
    _         _   _        _     _
   / \   _ __| |_(_)_  __ | |   (_)_ __  _   ___  __
  / _ \ | '__| __| \ \/ / | |   | | '_ \| | | \ \/ /
 / ___ \| |  | |_| |>  <  | |___| | | | | |_| |>  <
/_/   \_\_|   \__|_/_/\_\ |_____|_|_| |_|\__,_/_/\_\

         Surface Go 2 Installation Script
EOF
    echo -e "${NC}"
    echo
    echo "This script will install Artix Linux with:"
    echo "  - Full disk encryption (LUKS2)"
    echo "  - Runit init system"
    echo "  - Linux-surface kernel"
    echo "  - Hyprland desktop environment"
    echo

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${YELLOW}[DRY-RUN MODE] No changes will be made${NC}"
        echo
    fi

    echo -e "Log file: ${CYAN}${LOG_FILE}${NC}"
    echo

    if ! confirm "Ready to begin installation?" "n"; then
        echo "Installation cancelled."
        exit 0
    fi
}

# =============================================================================
# PRE-INSTALLATION CHECKS
# =============================================================================

pre_install_checks() {
    section "Pre-Installation Checks"

    # Check root
    check_root

    # Check live environment
    check_live_env

    # Check internet
    check_internet

    # Check required commands
    local required_cmds=(
        basestrap
        artix-chroot
        fstabgen
        sgdisk
        cryptsetup
        grub-install
    )

    for cmd in "${required_cmds[@]}"; do
        require_cmd "$cmd"
    done

    success "All pre-installation checks passed"
}

# =============================================================================
# INSTALLATION PHASES
# =============================================================================

phase_disk_setup() {
    section "Phase 1: Disk Setup"

    # Select target disk
    select_disk

    # Detect SD card for keyfile
    detect_sdcard

    # Wipe and partition disk
    wipe_disk "$TARGET_DISK"
    partition_disk "$TARGET_DISK"

    # Setup SD card if present
    if [[ -n "${SDCARD:-}" ]]; then
        partition_sdcard "$SDCARD"
    fi

    success "Disk setup complete"
}

phase_encryption() {
    section "Phase 2: Encryption Setup"

    # Setup LUKS on root partition
    setup_luks "$ROOT_PART"

    # Open LUKS container
    open_luks "$ROOT_PART"

    # Setup keyfile on SD card
    if [[ -n "${SDCARD_KEY:-}" ]]; then
        setup_sdcard_keyfile "$SDCARD_KEY" "$ROOT_PART"
    fi

    success "Encryption setup complete"
}

phase_filesystem() {
    section "Phase 3: Filesystem Setup"

    # Format partitions
    format_efi "$EFI_PART"
    format_root "$LUKS_MAPPER_PATH"

    # Mount filesystems
    mount_root "$LUKS_MAPPER_PATH" "/mnt"
    ensure_dir "/mnt/boot/efi"
    mount_efi "$EFI_PART" "/mnt/boot/efi"

    success "Filesystem setup complete"
}

phase_base_install() {
    section "Phase 4: Base System Installation"

    # Configure mirrors
    configure_mirrors "/mnt"

    # Install base system
    install_base_system "/mnt"

    # Generate fstab
    generate_fstab "/mnt"

    # Prepare chroot
    prepare_chroot "/mnt"

    success "Base system installation complete"
}

phase_system_config() {
    section "Phase 5: System Configuration"

    # Configure timezone and locale
    configure_timezone "/mnt"
    configure_locale "/mnt"

    # Configure hostname
    configure_hostname "/mnt"

    # Create user account
    create_user "/mnt"

    # Configure pacman
    configure_pacman "/mnt"

    success "System configuration complete"
}

phase_encryption_config() {
    section "Phase 6: Encryption Configuration"

    # Setup embedded keyfile
    setup_embedded_keyfile "/mnt" "$ROOT_PART"

    # Generate crypttab
    generate_crypttab "/mnt" "$ROOT_PART"

    # Configure mkinitcpio for LUKS
    configure_mkinitcpio_luks "/mnt"

    # Configure GRUB for encryption
    configure_grub_luks "/mnt" "$ROOT_PART"

    success "Encryption configuration complete"
}

phase_surface_setup() {
    section "Phase 7: Surface Hardware Setup"

    # Add linux-surface repository
    add_surface_repo "/mnt"

    # Run complete Surface setup
    setup_surface "/mnt"

    success "Surface hardware setup complete"
}

phase_packages() {
    section "Phase 8: Package Installation"

    # Install packages by category
    install_category "/mnt" "development"
    install_category "/mnt" "terminal"
    install_category "/mnt" "wayland"
    install_category "/mnt" "applications"
    install_category "/mnt" "utilities"
    install_category "/mnt" "audio"
    install_category "/mnt" "bluetooth"
    install_category "/mnt" "power"
    install_category "/mnt" "networking"
    install_category "/mnt" "fonts"
    install_category "/mnt" "communication"
    install_category "/mnt" "productivity"

    success "Package installation complete"
}

phase_user_setup() {
    section "Phase 9: User Environment Setup"

    # Setup zsh
    setup_zsh "/mnt" "$USERNAME"

    # Configure environment variables
    configure_environment "/mnt"

    # Deploy dotfiles
    deploy_dotfiles "/mnt" "$USERNAME"

    # Generate AUR package list for post-install
    generate_aur_list "/mnt"

    success "User environment setup complete"
}

phase_bootloader() {
    section "Phase 10: Bootloader Installation"

    # Regenerate initramfs (important after encryption config)
    regenerate_initramfs "/mnt"

    # Install GRUB
    install_grub "/mnt" "/boot/efi"

    success "Bootloader installation complete"
}

phase_services() {
    section "Phase 11: Service Configuration"

    # Enable essential services
    enable_services "/mnt"

    success "Service configuration complete"
}

phase_finalize() {
    section "Phase 12: Finalization"

    # Verify critical packages
    verify_packages "/mnt"

    # Copy installation scripts to new system
    info "Copying installation files to new system..."
    local install_dir="/mnt/home/${USERNAME}/artix-install"
    ensure_dir "$install_dir"
    cp -r "${SCRIPT_DIR}"/* "$install_dir/"
    run_in_chroot "/mnt" "chown -R ${USERNAME}:${USERNAME} /home/${USERNAME}/artix-install"

    # Unmount filesystems
    info "Unmounting filesystems..."
    unmount_all "/mnt"

    # Close LUKS container
    close_luks

    success "Finalization complete"
}

# =============================================================================
# COMPLETION
# =============================================================================

show_completion() {
    section "Installation Complete!"

    echo -e "${GREEN}"
    cat << 'EOF'
 ____                                  _
/ ___| _   _  ___ ___ ___  ___ ___ ___| |
\___ \| | | |/ __/ __/ _ \/ __/ __/ __| |
 ___) | |_| | (_| (_|  __/\__ \__ \__ \_|
|____/ \__,_|\___\___\___||___/___/___(_)

EOF
    echo -e "${NC}"

    echo "Artix Linux has been installed successfully!"
    echo
    echo "Next steps:"
    echo "  1. Remove the installation media"
    echo "  2. Reboot: ${CYAN}reboot${NC}"
    echo "  3. Log in with your user account"
    echo "  4. Review ${CYAN}~/post-install-aur.md${NC} for AUR packages"
    echo "  5. Install AUR packages using paru"
    echo
    echo "Installation log saved to: ${CYAN}${LOG_FILE}${NC}"
    echo

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${YELLOW}This was a dry run - no changes were made${NC}"
    fi
}

# =============================================================================
# MAIN
# =============================================================================

main() {
    # Parse command line arguments
    parse_args "$@"

    # Setup error handling
    setup_trap

    # Show welcome screen
    show_welcome

    # Run pre-installation checks
    pre_install_checks

    # Run installation phases
    phase_disk_setup
    phase_encryption
    phase_filesystem
    phase_base_install
    phase_system_config
    phase_encryption_config
    phase_surface_setup
    phase_packages
    phase_user_setup
    phase_bootloader
    phase_services
    phase_finalize

    # Show completion message
    show_completion
}

# Run main function
main "$@"
