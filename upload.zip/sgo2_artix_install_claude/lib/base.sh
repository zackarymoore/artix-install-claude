#!/bin/bash
# lib/base.sh - Base system installation functions for Artix Linux
# Surface Go 2 Installation Project

# =============================================================================
# BASE PACKAGE DEFINITIONS
# =============================================================================

# Essential base packages for Artix with runit
BASE_PACKAGES=(
    base
    base-devel
    linux-firmware
    intel-ucode
    runit
    elogind-runit
    grub
    efibootmgr
    os-prober
    cryptsetup
    lvm2
    mkinitcpio
)

# Networking packages (essential for post-install)
NETWORK_PACKAGES=(
    networkmanager
    networkmanager-runit
    dhcpcd
    iwd
    wpa_supplicant
)

# Bluetooth packages
BLUETOOTH_PACKAGES=(
    bluez
    bluez-utils
    bluez-runit
)

# Basic utilities needed for system administration
UTIL_PACKAGES=(
    sudo
    vim
    neovim
    git
    curl
    wget
    man-db
    man-pages
    which
    htop
    tree
)

# =============================================================================
# PACMAN MIRRORS
# =============================================================================

# Configure pacman mirrors
configure_mirrors() {
    local mount_point="${1:-/mnt}"

    section "Mirror Configuration"

    info "Configuring Artix Linux mirrors..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would configure mirrors"
        return 0
    fi

    # Rank mirrors or use defaults
    # Artix default mirrors are usually fine for most locations
    info "Using default Artix mirrors"

    success "Mirrors configured"
}

# =============================================================================
# BASESTRAP INSTALLATION
# =============================================================================

# Install base system using basestrap
install_base_system() {
    local mount_point="${1:-/mnt}"

    section "Base System Installation"

    info "Installing base system with basestrap..."

    # Combine all essential packages
    local all_packages=("${BASE_PACKAGES[@]}" "${NETWORK_PACKAGES[@]}" "${BLUETOOTH_PACKAGES[@]}" "${UTIL_PACKAGES[@]}")

    info "Packages to install:"
    echo "${all_packages[*]}" | tr ' ' '\n' | column

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would run: basestrap $mount_point ${all_packages[*]}"
        return 0
    fi

    # Run basestrap
    basestrap "$mount_point" "${all_packages[@]}"

    success "Base system installed"
}

# =============================================================================
# FSTAB GENERATION
# =============================================================================

# Generate fstab
generate_fstab() {
    local mount_point="${1:-/mnt}"

    section "Fstab Generation"

    info "Generating fstab..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would generate fstab"
        return 0
    fi

    # Generate fstab using UUIDs
    fstabgen -U "$mount_point" >> "${mount_point}/etc/fstab"

    # Show generated fstab
    info "Generated fstab:"
    cat "${mount_point}/etc/fstab"

    success "Fstab generated"
}

# =============================================================================
# CHROOT PREPARATION
# =============================================================================

# Prepare for chroot
prepare_chroot() {
    local mount_point="${1:-/mnt}"

    section "Chroot Preparation"

    info "Preparing chroot environment..."

    # Copy resolv.conf for network access in chroot
    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would prepare chroot"
        return 0
    fi

    # Ensure resolv.conf exists
    if [[ -f /etc/resolv.conf ]]; then
        cp /etc/resolv.conf "${mount_point}/etc/resolv.conf"
    fi

    success "Chroot environment prepared"
}

# Execute command in chroot
run_in_chroot() {
    local mount_point="${1:-/mnt}"
    shift
    local cmd="$*"

    debug "Running in chroot: $cmd"

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would run in chroot: $cmd"
        return 0
    fi

    artix-chroot "$mount_point" /bin/bash -c "$cmd"
}

# Copy script to chroot and execute
run_script_in_chroot() {
    local mount_point="${1:-/mnt}"
    local script="$2"
    local script_name
    script_name=$(basename "$script")

    info "Copying and executing $script_name in chroot..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would copy and run $script in chroot"
        return 0
    fi

    # Copy script to chroot
    cp "$script" "${mount_point}/tmp/${script_name}"
    chmod +x "${mount_point}/tmp/${script_name}"

    # Copy lib directory for dependencies
    if [[ -d "${SCRIPT_DIR}/lib" ]]; then
        cp -r "${SCRIPT_DIR}/lib" "${mount_point}/tmp/"
    fi

    # Copy config directory
    if [[ -d "${SCRIPT_DIR}/config" ]]; then
        cp -r "${SCRIPT_DIR}/config" "${mount_point}/tmp/"
    fi

    # Execute in chroot
    artix-chroot "$mount_point" /bin/bash "/tmp/${script_name}"

    # Cleanup
    rm -f "${mount_point}/tmp/${script_name}"

    success "Chroot script execution complete"
}

# =============================================================================
# BOOTLOADER INSTALLATION
# =============================================================================

# Install GRUB bootloader
install_grub() {
    local mount_point="${1:-/mnt}"
    local efi_directory="${2:-/boot/efi}"

    section "GRUB Installation"

    info "Installing GRUB bootloader..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would install GRUB"
        return 0
    fi

    # Install GRUB to EFI partition
    run_in_chroot "$mount_point" "grub-install --target=x86_64-efi --efi-directory=${efi_directory} --bootloader-id=ARTIX --recheck"

    # Generate GRUB config
    run_in_chroot "$mount_point" "grub-mkconfig -o /boot/grub/grub.cfg"

    success "GRUB installed and configured"
}

# =============================================================================
# INITRAMFS
# =============================================================================

# Regenerate initramfs
regenerate_initramfs() {
    local mount_point="${1:-/mnt}"

    section "Initramfs Generation"

    info "Regenerating initramfs..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would regenerate initramfs"
        return 0
    fi

    run_in_chroot "$mount_point" "mkinitcpio -P"

    success "Initramfs regenerated"
}

# =============================================================================
# TIMEZONE AND LOCALE
# =============================================================================

# Configure timezone
configure_timezone() {
    local mount_point="${1:-/mnt}"

    section "Timezone Configuration"

    # List common timezones
    info "Common timezones:"
    echo "1. America/New_York (Eastern)"
    echo "2. America/Chicago (Central)"
    echo "3. America/Denver (Mountain)"
    echo "4. America/Los_Angeles (Pacific)"
    echo "5. Europe/London"
    echo "6. Europe/Berlin"
    echo "7. Asia/Tokyo"
    echo "8. Custom"
    echo

    local choice
    choice=$(prompt_input "Select timezone" "4")

    local timezone
    case "$choice" in
        1) timezone="America/New_York" ;;
        2) timezone="America/Chicago" ;;
        3) timezone="America/Denver" ;;
        4) timezone="America/Los_Angeles" ;;
        5) timezone="Europe/London" ;;
        6) timezone="Europe/Berlin" ;;
        7) timezone="Asia/Tokyo" ;;
        8) timezone=$(prompt_input "Enter timezone (e.g., America/New_York)") ;;
        *) timezone="America/Los_Angeles" ;;
    esac

    info "Setting timezone to $timezone..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would set timezone to $timezone"
        return 0
    fi

    run_in_chroot "$mount_point" "ln -sf /usr/share/zoneinfo/${timezone} /etc/localtime"
    run_in_chroot "$mount_point" "hwclock --systohc"

    success "Timezone configured"

    export TIMEZONE="$timezone"
}

# Configure locale
configure_locale() {
    local mount_point="${1:-/mnt}"
    local locale="${2:-en_US.UTF-8}"

    section "Locale Configuration"

    info "Configuring locale ($locale)..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would configure locale $locale"
        return 0
    fi

    # Uncomment locale in locale.gen
    sed -i "s/^#${locale}/${locale}/" "${mount_point}/etc/locale.gen"

    # Also enable en_US.UTF-8 if different locale selected
    if [[ "$locale" != "en_US.UTF-8" ]]; then
        sed -i "s/^#en_US.UTF-8/en_US.UTF-8/" "${mount_point}/etc/locale.gen"
    fi

    # Generate locales
    run_in_chroot "$mount_point" "locale-gen"

    # Set system locale
    echo "LANG=${locale}" > "${mount_point}/etc/locale.conf"

    # Set console keymap
    echo "KEYMAP=us" > "${mount_point}/etc/vconsole.conf"

    success "Locale configured"
}

# =============================================================================
# HOSTNAME AND HOSTS
# =============================================================================

# Configure hostname
configure_hostname() {
    local mount_point="${1:-/mnt}"

    section "Hostname Configuration"

    local hostname
    hostname=$(prompt_input "Enter hostname" "surface-go")

    info "Setting hostname to $hostname..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would set hostname to $hostname"
        export HOSTNAME="$hostname"
        return 0
    fi

    # Set hostname
    echo "$hostname" > "${mount_point}/etc/hostname"

    # Configure hosts file
    cat > "${mount_point}/etc/hosts" << EOF
# Static table lookup for hostnames.
# See hosts(5) for details.

127.0.0.1       localhost
::1             localhost
127.0.1.1       ${hostname}.localdomain ${hostname}
EOF

    success "Hostname configured"

    export HOSTNAME="$hostname"
}

# =============================================================================
# USER CREATION
# =============================================================================

# Create user account
create_user() {
    local mount_point="${1:-/mnt}"

    section "User Account Creation"

    local username
    username=$(prompt_input "Enter username" "user")

    info "Creating user account: $username..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would create user $username"
        export USERNAME="$username"
        return 0
    fi

    # Create user with home directory
    run_in_chroot "$mount_point" "useradd -m -G wheel,audio,video,input,storage,optical -s /bin/bash ${username}"

    # Set user password
    info "Set password for $username:"
    run_in_chroot "$mount_point" "passwd ${username}"

    # Set root password
    info "Set root password:"
    run_in_chroot "$mount_point" "passwd root"

    # Enable sudo for wheel group
    sed -i 's/^# %wheel ALL=(ALL:ALL) ALL/%wheel ALL=(ALL:ALL) ALL/' "${mount_point}/etc/sudoers"

    success "User account created"

    export USERNAME="$username"
}

# =============================================================================
# SERVICES
# =============================================================================

# Enable runit services
enable_services() {
    local mount_point="${1:-/mnt}"

    section "Service Configuration"

    info "Enabling essential services..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would enable services"
        return 0
    fi

    # Services to enable
    local services=(
        "NetworkManager"
        "bluetoothd"
        "elogind"
    )

    for service in "${services[@]}"; do
        local service_path="/etc/runit/sv/${service}"
        local runsvdir="/etc/runit/runsvdir/default"

        if [[ -d "${mount_point}${service_path}" ]]; then
            run_in_chroot "$mount_point" "ln -sf ${service_path} ${runsvdir}/"
            info "Enabled service: $service"
        else
            warn "Service not found: $service"
        fi
    done

    success "Services enabled"
}

# =============================================================================
# EXPORTS
# =============================================================================
export BASE_PACKAGES NETWORK_PACKAGES BLUETOOTH_PACKAGES UTIL_PACKAGES
export TIMEZONE HOSTNAME USERNAME
