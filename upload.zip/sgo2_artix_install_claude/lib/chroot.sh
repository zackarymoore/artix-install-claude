#!/bin/bash
# lib/chroot.sh - Chroot configuration functions for Artix Linux installation
# Surface Go 2 Installation Project

# =============================================================================
# CHROOT ENVIRONMENT SETUP
# =============================================================================

# Setup chroot environment with proper mounts
setup_chroot_mounts() {
    local mount_point="${1:-/mnt}"

    info "Setting up chroot mounts..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would setup chroot mounts"
        return 0
    fi

    # Mount proc
    mount -t proc proc "${mount_point}/proc"

    # Mount sys
    mount -t sysfs sys "${mount_point}/sys"

    # Mount dev
    mount --rbind /dev "${mount_point}/dev"
    mount --make-rslave "${mount_point}/dev"

    # Mount run
    mount --rbind /run "${mount_point}/run"
    mount --make-rslave "${mount_point}/run"

    # Mount EFI variables (for UEFI systems)
    if [[ -d /sys/firmware/efi/efivars ]]; then
        mount --rbind /sys/firmware/efi/efivars "${mount_point}/sys/firmware/efi/efivars"
    fi

    success "Chroot mounts configured"
}

# Cleanup chroot mounts
cleanup_chroot_mounts() {
    local mount_point="${1:-/mnt}"

    info "Cleaning up chroot mounts..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would cleanup chroot mounts"
        return 0
    fi

    # Unmount in reverse order
    umount -l "${mount_point}/sys/firmware/efi/efivars" 2>/dev/null || true
    umount -l "${mount_point}/run" 2>/dev/null || true
    umount -l "${mount_point}/dev" 2>/dev/null || true
    umount -l "${mount_point}/sys" 2>/dev/null || true
    umount -l "${mount_point}/proc" 2>/dev/null || true

    success "Chroot mounts cleaned up"
}

# =============================================================================
# PACMAN CONFIGURATION
# =============================================================================

# Configure pacman for chroot
configure_pacman() {
    local mount_point="${1:-/mnt}"
    local pacman_conf="${mount_point}/etc/pacman.conf"

    section "Pacman Configuration"

    info "Configuring pacman..."

    if [[ ! -f "$pacman_conf" ]]; then
        warn "pacman.conf not found at $pacman_conf"
        return 1
    fi

    backup_file "$pacman_conf"

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would configure pacman"
        return 0
    fi

    # Enable Color
    sed -i 's/^#Color/Color/' "$pacman_conf"

    # Enable ParallelDownloads
    sed -i 's/^#ParallelDownloads = 5/ParallelDownloads = 5/' "$pacman_conf"

    # Enable VerbosePkgLists
    sed -i 's/^#VerbosePkgLists/VerbosePkgLists/' "$pacman_conf"

    # Enable multilib repository (if 32-bit support needed)
    # Uncomment [multilib] and Include lines
    # sed -i '/\[multilib\]/,/Include/s/^#//' "$pacman_conf"

    success "Pacman configured"
}

# Add Arch repositories to pacman (optional, use with caution)
add_arch_repos() {
    local mount_point="${1:-/mnt}"
    local pacman_conf="${mount_point}/etc/pacman.conf"

    section "Arch Repository Configuration"

    warn "Adding Arch repositories is not recommended for stability"

    if ! confirm "Do you want to add Arch repositories? (Not recommended)"; then
        info "Skipping Arch repositories"
        return 0
    fi

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would add Arch repositories"
        return 0
    fi

    # Add Arch repos (Universe first, then extra)
    cat >> "$pacman_conf" << 'EOF'

# Arch Linux repositories (use with caution)
# Uncomment only if needed

#[extra]
#Include = /etc/pacman.d/mirrorlist-arch

#[multilib]
#Include = /etc/pacman.d/mirrorlist-arch
EOF

    # Create Arch mirrorlist
    cat > "${mount_point}/etc/pacman.d/mirrorlist-arch" << 'EOF'
# Arch Linux mirrorlist
Server = https://geo.mirror.pkgbuild.com/$repo/os/$arch
Server = https://mirror.rackspace.com/archlinux/$repo/os/$arch
Server = https://mirrors.kernel.org/archlinux/$repo/os/$arch
EOF

    info "Arch repositories added (commented out by default)"
}

# =============================================================================
# LINUX-SURFACE REPOSITORY
# =============================================================================

# Add linux-surface repository for Surface kernel
add_surface_repo() {
    local mount_point="${1:-/mnt}"
    local pacman_conf="${mount_point}/etc/pacman.conf"

    section "Linux-Surface Repository"

    info "Adding linux-surface repository..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would add linux-surface repository"
        return 0
    fi

    # Add linux-surface repo key
    run_in_chroot "$mount_point" "curl -s https://raw.githubusercontent.com/linux-surface/linux-surface/master/pkg/keys/surface.asc | pacman-key --add -"
    run_in_chroot "$mount_point" "pacman-key --finger 56C464BAAC421453"
    run_in_chroot "$mount_point" "pacman-key --lsign-key 56C464BAAC421453"

    # Add repository to pacman.conf
    cat >> "$pacman_conf" << 'EOF'

# Linux Surface kernel repository
[linux-surface]
Server = https://pkg.surfacelinux.com/arch/
EOF

    # Sync repos
    run_in_chroot "$mount_point" "pacman -Sy"

    success "Linux-surface repository added"
}

# =============================================================================
# AUR HELPER SETUP
# =============================================================================

# Install paru AUR helper (run as regular user)
install_aur_helper() {
    local mount_point="${1:-/mnt}"
    local username="${2:-$USERNAME}"

    section "AUR Helper Installation"

    info "Installing paru AUR helper..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would install paru"
        return 0
    fi

    # Install dependencies
    run_in_chroot "$mount_point" "pacman -S --noconfirm --needed git base-devel"

    # Clone and build paru as regular user
    cat > "${mount_point}/tmp/install-paru.sh" << 'EOFSCRIPT'
#!/bin/bash
set -e
cd /tmp
git clone https://aur.archlinux.org/paru-bin.git
cd paru-bin
makepkg -si --noconfirm
cd ..
rm -rf paru-bin
EOFSCRIPT

    chmod +x "${mount_point}/tmp/install-paru.sh"

    # Run as regular user
    run_in_chroot "$mount_point" "su - ${username} -c '/tmp/install-paru.sh'"

    rm -f "${mount_point}/tmp/install-paru.sh"

    success "Paru AUR helper installed"
}

# =============================================================================
# SHELL CONFIGURATION
# =============================================================================

# Install and configure zsh as default shell
setup_zsh() {
    local mount_point="${1:-/mnt}"
    local username="${2:-$USERNAME}"

    section "ZSH Shell Setup"

    info "Setting up zsh..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would setup zsh"
        return 0
    fi

    # Install zsh
    run_in_chroot "$mount_point" "pacman -S --noconfirm --needed zsh zsh-completions zsh-autosuggestions zsh-syntax-highlighting"

    # Change default shell for user
    run_in_chroot "$mount_point" "chsh -s /bin/zsh ${username}"

    success "ZSH configured as default shell"
}

# =============================================================================
# DOTFILES DEPLOYMENT
# =============================================================================

# Deploy dotfiles to user home
deploy_dotfiles() {
    local mount_point="${1:-/mnt}"
    local username="${2:-$USERNAME}"
    local dotfiles_src="${3:-${SCRIPT_DIR}/dotfiles}"

    section "Dotfiles Deployment"

    if [[ ! -d "$dotfiles_src" ]]; then
        warn "Dotfiles directory not found: $dotfiles_src"
        return 0
    fi

    local user_home="${mount_point}/home/${username}"

    info "Deploying dotfiles to $user_home..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would deploy dotfiles"
        return 0
    fi

    # Create config directories
    ensure_dir "${user_home}/.config"

    # Copy dotfiles
    for dir in "$dotfiles_src"/*/; do
        local dir_name
        dir_name=$(basename "$dir")
        info "Deploying ${dir_name}..."
        cp -r "$dir" "${user_home}/.config/"
    done

    # Copy root-level dotfiles (like .zshrc)
    for file in "$dotfiles_src"/.* ; do
        if [[ -f "$file" ]]; then
            local file_name
            file_name=$(basename "$file")
            info "Deploying ${file_name}..."
            cp "$file" "${user_home}/"
        fi
    done

    # Fix ownership
    run_in_chroot "$mount_point" "chown -R ${username}:${username} /home/${username}"

    success "Dotfiles deployed"
}

# =============================================================================
# ENVIRONMENT VARIABLES
# =============================================================================

# Configure environment variables
configure_environment() {
    local mount_point="${1:-/mnt}"

    section "Environment Configuration"

    info "Configuring environment variables..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would configure environment"
        return 0
    fi

    # Create environment file
    cat > "${mount_point}/etc/environment" << 'EOF'
# System-wide environment variables

# Wayland
MOZ_ENABLE_WAYLAND=1
QT_QPA_PLATFORM=wayland
SDL_VIDEODRIVER=wayland
CLUTTER_BACKEND=wayland
XDG_SESSION_TYPE=wayland

# Editor
EDITOR=nvim
VISUAL=nvim

# Pager
PAGER=less

# History
HISTSIZE=10000
HISTFILESIZE=20000
EOF

    # XDG directories
    cat > "${mount_point}/etc/profile.d/xdg.sh" << 'EOF'
#!/bin/sh
# XDG Base Directory Specification

export XDG_CONFIG_HOME="${HOME}/.config"
export XDG_CACHE_HOME="${HOME}/.cache"
export XDG_DATA_HOME="${HOME}/.local/share"
export XDG_STATE_HOME="${HOME}/.local/state"
export XDG_RUNTIME_DIR="/run/user/$(id -u)"
EOF

    chmod +x "${mount_point}/etc/profile.d/xdg.sh"

    success "Environment configured"
}

# =============================================================================
# WAYLAND SESSION SETUP
# =============================================================================

# Configure Wayland session
configure_wayland_session() {
    local mount_point="${1:-/mnt}"

    section "Wayland Session Configuration"

    info "Configuring Wayland session..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would configure Wayland session"
        return 0
    fi

    # Create wayland session script
    cat > "${mount_point}/etc/profile.d/wayland-session.sh" << 'EOF'
#!/bin/sh
# Start Hyprland on tty1 login

if [ -z "${DISPLAY}" ] && [ "${XDG_VTNR}" -eq 1 ]; then
    exec Hyprland
fi
EOF

    chmod +x "${mount_point}/etc/profile.d/wayland-session.sh"

    success "Wayland session configured"
}

# =============================================================================
# EXPORTS
# =============================================================================
export -f setup_chroot_mounts cleanup_chroot_mounts
export -f configure_pacman add_arch_repos add_surface_repo
export -f install_aur_helper setup_zsh deploy_dotfiles
export -f configure_environment configure_wayland_session
