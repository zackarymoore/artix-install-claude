#!/bin/bash
# lib/common.sh - Shared utility functions for Artix Linux installation
# Surface Go 2 Installation Project

set -euo pipefail

# =============================================================================
# COLOR DEFINITIONS
# =============================================================================
readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly MAGENTA='\033[0;35m'
readonly CYAN='\033[0;36m'
readonly WHITE='\033[1;37m'
readonly NC='\033[0m' # No Color

# =============================================================================
# GLOBAL VARIABLES
# =============================================================================
DRY_RUN=${DRY_RUN:-false}
VERBOSE=${VERBOSE:-false}
LOG_FILE="/tmp/artix-install-$(date +%Y%m%d-%H%M%S).log"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

# =============================================================================
# LOGGING FUNCTIONS
# =============================================================================

log() {
    local level="$1"
    shift
    local message="$*"
    local timestamp
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')

    echo "[$timestamp] [$level] $message" >> "$LOG_FILE"

    case "$level" in
        INFO)    echo -e "${CYAN}[INFO]${NC} $message" ;;
        SUCCESS) echo -e "${GREEN}[SUCCESS]${NC} $message" ;;
        WARN)    echo -e "${YELLOW}[WARNING]${NC} $message" ;;
        ERROR)   echo -e "${RED}[ERROR]${NC} $message" >&2 ;;
        DEBUG)   [[ "$VERBOSE" == "true" ]] && echo -e "${MAGENTA}[DEBUG]${NC} $message" ;;
    esac
}

info()    { log "INFO" "$@"; }
success() { log "SUCCESS" "$@"; }
warn()    { log "WARN" "$@"; }
error()   { log "ERROR" "$@"; }
debug()   { log "DEBUG" "$@"; }

# =============================================================================
# USER INTERACTION
# =============================================================================

# Print a section header
section() {
    local title="$1"
    echo
    echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
    echo -e "${WHITE}  $title${NC}"
    echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
    echo
}

# Prompt user for yes/no confirmation
confirm() {
    local prompt="${1:-Continue?}"
    local default="${2:-n}"
    local response

    if [[ "$default" == "y" ]]; then
        prompt="$prompt [Y/n]: "
    else
        prompt="$prompt [y/N]: "
    fi

    read -rp "$(echo -e "${YELLOW}$prompt${NC}")" response
    response=${response:-$default}

    [[ "${response,,}" == "y" || "${response,,}" == "yes" ]]
}

# Prompt for input with default value
prompt_input() {
    local prompt="$1"
    local default="${2:-}"
    local response

    if [[ -n "$default" ]]; then
        read -rp "$(echo -e "${CYAN}$prompt${NC} [$default]: ")" response
        echo "${response:-$default}"
    else
        read -rp "$(echo -e "${CYAN}$prompt${NC}: ")" response
        echo "$response"
    fi
}

# Prompt for password (hidden input)
prompt_password() {
    local prompt="$1"
    local password

    read -srp "$(echo -e "${CYAN}$prompt${NC}: ")" password
    echo
    echo "$password"
}

# =============================================================================
# COMMAND EXECUTION
# =============================================================================

# Execute command (or simulate in dry-run mode)
run() {
    local cmd="$*"

    debug "Executing: $cmd"

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would execute: $cmd"
        return 0
    fi

    if ! eval "$cmd"; then
        error "Command failed: $cmd"
        return 1
    fi
}

# Execute command with sudo
run_sudo() {
    run "sudo $*"
}

# =============================================================================
# SYSTEM CHECKS
# =============================================================================

# Check if running as root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        error "This script must be run as root"
        exit 1
    fi
}

# Check if NOT running as root
check_not_root() {
    if [[ $EUID -eq 0 ]]; then
        error "This script should not be run as root"
        exit 1
    fi
}

# Check if running from live environment
check_live_env() {
    if ! grep -q "artix" /etc/os-release 2>/dev/null; then
        warn "This doesn't appear to be an Artix Linux environment"
        if ! confirm "Continue anyway?"; then
            exit 1
        fi
    fi
}

# Check if a command exists
cmd_exists() {
    command -v "$1" &>/dev/null
}

# Require a command to exist
require_cmd() {
    local cmd="$1"
    if ! cmd_exists "$cmd"; then
        error "Required command not found: $cmd"
        exit 1
    fi
}

# =============================================================================
# DEVICE/DISK UTILITIES
# =============================================================================

# List available block devices
list_disks() {
    lsblk -dpno NAME,SIZE,MODEL | grep -v "loop\|sr\|rom"
}

# Check if device exists
device_exists() {
    [[ -b "$1" ]]
}

# Get device size in bytes
get_device_size() {
    local device="$1"
    blockdev --getsize64 "$device"
}

# Check if device is mounted
is_mounted() {
    local device="$1"
    mount | grep -q "^$device"
}

# Unmount device if mounted
ensure_unmounted() {
    local device="$1"
    if is_mounted "$device"; then
        info "Unmounting $device..."
        run "umount -f $device" || true
    fi
}

# =============================================================================
# FILE UTILITIES
# =============================================================================

# Backup a file before modifying
backup_file() {
    local file="$1"
    if [[ -f "$file" ]]; then
        local backup="${file}.backup-$(date +%Y%m%d-%H%M%S)"
        cp "$file" "$backup"
        debug "Backed up $file to $backup"
    fi
}

# Create directory if it doesn't exist
ensure_dir() {
    local dir="$1"
    if [[ ! -d "$dir" ]]; then
        run "mkdir -p $dir"
    fi
}

# Copy file with logging
copy_file() {
    local src="$1"
    local dest="$2"
    info "Copying $src to $dest"
    run "cp -a $src $dest"
}

# =============================================================================
# PACKAGE MANAGEMENT
# =============================================================================

# Install packages (for live environment)
install_pkg() {
    local pkgs="$*"
    info "Installing packages: $pkgs"
    run "pacman -Sy --noconfirm --needed $pkgs"
}

# Check if package is installed
pkg_installed() {
    pacman -Qi "$1" &>/dev/null
}

# =============================================================================
# CLEANUP AND ERROR HANDLING
# =============================================================================

# Cleanup function for traps
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        error "Installation failed with exit code $exit_code"
        error "Check log file: $LOG_FILE"
    fi
}

# Set up trap for cleanup
setup_trap() {
    trap cleanup EXIT
}

# =============================================================================
# PROGRESS INDICATION
# =============================================================================

# Simple spinner for long operations
spinner() {
    local pid=$1
    local message="${2:-Processing...}"
    local spin='-\|/'
    local i=0

    while kill -0 "$pid" 2>/dev/null; do
        i=$(( (i+1) %4 ))
        printf "\r${CYAN}[%c]${NC} %s" "${spin:$i:1}" "$message"
        sleep 0.1
    done
    printf "\r"
}

# =============================================================================
# NETWORK
# =============================================================================

# Check internet connectivity
check_internet() {
    info "Checking internet connectivity..."
    if ! ping -c 1 -W 5 artixlinux.org &>/dev/null; then
        error "No internet connection detected"
        return 1
    fi
    success "Internet connection verified"
}

# =============================================================================
# EXPORTS
# =============================================================================
export DRY_RUN VERBOSE LOG_FILE SCRIPT_DIR
export RED GREEN YELLOW BLUE MAGENTA CYAN WHITE NC
