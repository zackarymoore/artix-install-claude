#!/bin/bash
# lib/disk.sh - Disk partitioning functions for Artix Linux installation
# Surface Go 2 Installation Project

# =============================================================================
# DISK CONFIGURATION
# =============================================================================

# Default partition sizes (for 64GB eMMC)
EFI_SIZE="512M"
ROOT_SIZE="100%"  # Use remaining space

# Partition labels
EFI_LABEL="EFI"
ROOT_LABEL="ARTIX_ROOT"

# =============================================================================
# DISK SELECTION
# =============================================================================

# Select target disk interactively
select_disk() {
    section "Disk Selection"

    info "Available disks:"
    echo
    list_disks | nl -w2 -s'. '
    echo

    local disks
    readarray -t disks < <(list_disks | awk '{print $1}')

    local choice
    while true; do
        choice=$(prompt_input "Select disk number" "1")

        if [[ "$choice" =~ ^[0-9]+$ ]] && (( choice >= 1 && choice <= ${#disks[@]} )); then
            TARGET_DISK="${disks[$((choice-1))]}"
            break
        else
            warn "Invalid selection. Please enter a number between 1 and ${#disks[@]}"
        fi
    done

    info "Selected disk: $TARGET_DISK"

    # Show disk details
    echo
    lsblk "$TARGET_DISK" -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINT
    echo

    # Confirm selection
    warn "ALL DATA ON $TARGET_DISK WILL BE DESTROYED!"
    if ! confirm "Are you absolutely sure you want to continue?"; then
        error "Installation aborted by user"
        exit 1
    fi

    export TARGET_DISK
}

# =============================================================================
# DISK PREPARATION
# =============================================================================

# Wipe disk signatures
wipe_disk() {
    local disk="$1"
    info "Wiping disk signatures on $disk..."

    # Unmount any mounted partitions
    for part in "${disk}"*; do
        ensure_unmounted "$part"
    done

    # Close any LUKS containers
    for mapper in /dev/mapper/luks-*; do
        if [[ -b "$mapper" ]]; then
            run "cryptsetup close $(basename "$mapper")" || true
        fi
    done

    # Wipe partition table and filesystem signatures
    run "wipefs -af $disk"
    run "sgdisk -Z $disk"

    # Inform kernel of changes
    run "partprobe $disk"
    sleep 2
}

# =============================================================================
# PARTITIONING
# =============================================================================

# Create GPT partition table and partitions
partition_disk() {
    local disk="$1"

    section "Partitioning Disk"
    info "Creating partition scheme on $disk..."

    # Create GPT partition table
    run "sgdisk -o $disk"

    # Create EFI partition (partition 1)
    info "Creating EFI partition (${EFI_SIZE})..."
    run "sgdisk -n 1:0:+${EFI_SIZE} -t 1:ef00 -c 1:${EFI_LABEL} $disk"

    # Create root partition (partition 2, remaining space)
    info "Creating root partition (remaining space)..."
    run "sgdisk -n 2:0:0 -t 2:8309 -c 2:${ROOT_LABEL} $disk"

    # Print partition table
    run "sgdisk -p $disk"

    # Inform kernel of changes
    run "partprobe $disk"
    sleep 2

    # Determine partition naming convention (nvme vs sd)
    if [[ "$disk" == *"nvme"* ]] || [[ "$disk" == *"mmcblk"* ]]; then
        EFI_PART="${disk}p1"
        ROOT_PART="${disk}p2"
    else
        EFI_PART="${disk}1"
        ROOT_PART="${disk}2"
    fi

    export EFI_PART ROOT_PART

    success "Partitioning complete"
    info "EFI partition: $EFI_PART"
    info "Root partition: $ROOT_PART"
}

# =============================================================================
# FILESYSTEM CREATION
# =============================================================================

# Format EFI partition
format_efi() {
    local part="$1"
    info "Formatting EFI partition as FAT32..."
    run "mkfs.fat -F32 -n ${EFI_LABEL} $part"
    success "EFI partition formatted"
}

# Format root partition (after LUKS setup)
format_root() {
    local part="$1"
    info "Formatting root partition as ext4..."
    run "mkfs.ext4 -L ${ROOT_LABEL} $part"
    success "Root partition formatted"
}

# =============================================================================
# MOUNTING
# =============================================================================

# Mount root filesystem
mount_root() {
    local part="$1"
    local mount_point="${2:-/mnt}"

    info "Mounting root filesystem at $mount_point..."
    ensure_dir "$mount_point"
    run "mount $part $mount_point"
    success "Root filesystem mounted"

    export MOUNT_POINT="$mount_point"
}

# Mount EFI partition
mount_efi() {
    local part="$1"
    local mount_point="${2:-/mnt/boot/efi}"

    info "Mounting EFI partition at $mount_point..."
    ensure_dir "$mount_point"
    run "mount $part $mount_point"
    success "EFI partition mounted"

    export EFI_MOUNT="$mount_point"
}

# Unmount all installation mounts
unmount_all() {
    local mount_point="${1:-/mnt}"

    info "Unmounting all filesystems..."

    # Unmount in reverse order
    for mp in "$mount_point"/boot/efi "$mount_point"/boot "$mount_point"; do
        if mountpoint -q "$mp" 2>/dev/null; then
            run "umount -R $mp" || warn "Failed to unmount $mp"
        fi
    done

    success "All filesystems unmounted"
}

# =============================================================================
# SD CARD HANDLING
# =============================================================================

# Detect SD card for keyfile storage
detect_sdcard() {
    section "SD Card Detection"

    info "Looking for SD card..."

    # Common SD card device patterns
    local sd_devices=()
    for dev in /dev/mmcblk[1-9] /dev/sd[b-z]; do
        if [[ -b "$dev" ]] && [[ "$dev" != "$TARGET_DISK" ]]; then
            sd_devices+=("$dev")
        fi
    done

    if [[ ${#sd_devices[@]} -eq 0 ]]; then
        warn "No SD card detected"
        if confirm "Continue without SD card keyfile?"; then
            SDCARD=""
            return 0
        else
            error "Installation requires SD card for keyfile"
            exit 1
        fi
    fi

    info "Found potential SD cards:"
    for i in "${!sd_devices[@]}"; do
        echo "$((i+1)). ${sd_devices[$i]} - $(lsblk -dno SIZE,MODEL "${sd_devices[$i]}" 2>/dev/null || echo "Unknown")"
    done

    local choice
    choice=$(prompt_input "Select SD card for keyfile storage" "1")

    if [[ "$choice" =~ ^[0-9]+$ ]] && (( choice >= 1 && choice <= ${#sd_devices[@]} )); then
        SDCARD="${sd_devices[$((choice-1))]}"
        info "Selected SD card: $SDCARD"
    else
        warn "Invalid selection, continuing without SD card keyfile"
        SDCARD=""
    fi

    export SDCARD
}

# Partition SD card for keyfile storage
partition_sdcard() {
    local sd="$1"

    if [[ -z "$sd" ]]; then
        return 0
    fi

    section "SD Card Setup"

    info "Setting up SD card for keyfile and storage..."
    warn "This will format the SD card!"

    if ! confirm "Proceed with SD card setup?"; then
        SDCARD=""
        return 0
    fi

    # Wipe and partition
    run "wipefs -af $sd"
    run "sgdisk -Z $sd"

    # Create two partitions:
    # 1. Small partition for keyfile (32MB, hidden)
    # 2. Rest for general storage (ext4)
    run "sgdisk -n 1:0:+32M -t 1:8300 -c 1:KEYFILE $sd"
    run "sgdisk -n 2:0:0 -t 2:8300 -c 2:STORAGE $sd"

    run "partprobe $sd"
    sleep 2

    # Determine partition names
    if [[ "$sd" == *"mmcblk"* ]]; then
        SDCARD_KEY="${sd}p1"
        SDCARD_STORAGE="${sd}p2"
    else
        SDCARD_KEY="${sd}1"
        SDCARD_STORAGE="${sd}2"
    fi

    # Format partitions
    run "mkfs.ext4 -L KEYFILE $SDCARD_KEY"
    run "mkfs.ext4 -L STORAGE $SDCARD_STORAGE"

    export SDCARD_KEY SDCARD_STORAGE

    success "SD card setup complete"
}

# =============================================================================
# EXPORTS
# =============================================================================
export TARGET_DISK EFI_PART ROOT_PART MOUNT_POINT EFI_MOUNT
export SDCARD SDCARD_KEY SDCARD_STORAGE
export EFI_SIZE ROOT_SIZE EFI_LABEL ROOT_LABEL
