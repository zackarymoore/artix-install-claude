#!/bin/bash
# lib/encryption.sh - LUKS encryption functions for Artix Linux installation
# Surface Go 2 Installation Project

# =============================================================================
# LUKS CONFIGURATION
# =============================================================================

LUKS_MAPPER_NAME="cryptroot"
LUKS_MAPPER_PATH="/dev/mapper/${LUKS_MAPPER_NAME}"
KEYFILE_PATH="/crypto_keyfile.bin"
KEYFILE_SIZE=4096  # 4KB keyfile

# LUKS2 options optimized for eMMC/SSD
LUKS_CIPHER="aes-xts-plain64"
LUKS_KEY_SIZE="512"
LUKS_HASH="sha512"
LUKS_ITER_TIME="3000"  # ms for PBKDF2 iterations

# =============================================================================
# LUKS SETUP
# =============================================================================

# Setup LUKS encryption on partition
setup_luks() {
    local partition="$1"

    section "LUKS Encryption Setup"

    info "Setting up LUKS2 encryption on $partition..."

    # Get encryption password
    local password password_confirm
    while true; do
        password=$(prompt_password "Enter encryption password")
        password_confirm=$(prompt_password "Confirm encryption password")

        if [[ "$password" != "$password_confirm" ]]; then
            warn "Passwords do not match. Please try again."
            continue
        fi

        if [[ ${#password} -lt 8 ]]; then
            warn "Password must be at least 8 characters"
            continue
        fi

        break
    done

    # Format partition with LUKS2
    info "Formatting partition with LUKS2..."
    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would format $partition with LUKS2"
    else
        echo -n "$password" | cryptsetup luksFormat \
            --type luks2 \
            --cipher "$LUKS_CIPHER" \
            --key-size "$LUKS_KEY_SIZE" \
            --hash "$LUKS_HASH" \
            --iter-time "$LUKS_ITER_TIME" \
            --use-urandom \
            --verify-passphrase \
            --batch-mode \
            "$partition" -
    fi

    success "LUKS container created"

    # Store password for subsequent operations
    LUKS_PASSWORD="$password"
    export LUKS_PASSWORD
}

# Open LUKS container
open_luks() {
    local partition="$1"
    local mapper_name="${2:-$LUKS_MAPPER_NAME}"

    info "Opening LUKS container..."

    if [[ -b "/dev/mapper/$mapper_name" ]]; then
        warn "LUKS container already open at /dev/mapper/$mapper_name"
        return 0
    fi

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would open LUKS container"
        return 0
    fi

    if [[ -n "${LUKS_PASSWORD:-}" ]]; then
        echo -n "$LUKS_PASSWORD" | cryptsetup open "$partition" "$mapper_name" -
    else
        cryptsetup open "$partition" "$mapper_name"
    fi

    success "LUKS container opened at /dev/mapper/$mapper_name"

    export LUKS_MAPPER_PATH="/dev/mapper/$mapper_name"
}

# Close LUKS container
close_luks() {
    local mapper_name="${1:-$LUKS_MAPPER_NAME}"

    if [[ -b "/dev/mapper/$mapper_name" ]]; then
        info "Closing LUKS container..."
        run "cryptsetup close $mapper_name"
        success "LUKS container closed"
    fi
}

# =============================================================================
# KEYFILE MANAGEMENT
# =============================================================================

# Generate random keyfile
generate_keyfile() {
    local keyfile_dest="$1"

    info "Generating random keyfile..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would generate keyfile at $keyfile_dest"
        return 0
    fi

    # Generate keyfile with random data
    dd bs=512 count=$((KEYFILE_SIZE / 512)) if=/dev/urandom of="$keyfile_dest" status=progress

    # Secure permissions
    chmod 000 "$keyfile_dest"

    success "Keyfile generated at $keyfile_dest"
}

# Add keyfile to LUKS container
add_keyfile_to_luks() {
    local partition="$1"
    local keyfile="$2"

    info "Adding keyfile to LUKS container..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would add keyfile to LUKS"
        return 0
    fi

    if [[ -n "${LUKS_PASSWORD:-}" ]]; then
        echo -n "$LUKS_PASSWORD" | cryptsetup luksAddKey "$partition" "$keyfile" -
    else
        cryptsetup luksAddKey "$partition" "$keyfile"
    fi

    success "Keyfile added to LUKS container"
}

# Setup keyfile on SD card
setup_sdcard_keyfile() {
    local sd_keyfile_part="$1"
    local luks_partition="$2"

    if [[ -z "$sd_keyfile_part" ]]; then
        info "Skipping SD card keyfile setup (no SD card)"
        return 0
    fi

    section "SD Card Keyfile Setup"

    local sd_mount="/tmp/sdcard_keyfile"
    ensure_dir "$sd_mount"

    # Mount SD card keyfile partition
    run "mount $sd_keyfile_part $sd_mount"

    # Generate keyfile on SD card
    local keyfile_path="${sd_mount}/crypto_keyfile.bin"
    generate_keyfile "$keyfile_path"

    # Add keyfile to LUKS
    add_keyfile_to_luks "$luks_partition" "$keyfile_path"

    # Unmount SD card
    run "umount $sd_mount"

    success "SD card keyfile setup complete"

    # Store keyfile device UUID for crypttab
    SDCARD_KEY_UUID=$(blkid -s UUID -o value "$sd_keyfile_part")
    export SDCARD_KEY_UUID
}

# =============================================================================
# EMBEDDED KEYFILE (for initramfs)
# =============================================================================

# Create keyfile embedded in initramfs
setup_embedded_keyfile() {
    local mount_point="$1"
    local luks_partition="$2"

    section "Embedded Keyfile Setup"

    info "Creating embedded keyfile for initramfs..."

    local keyfile="${mount_point}${KEYFILE_PATH}"

    # Generate keyfile in target system
    generate_keyfile "$keyfile"

    # Add keyfile to LUKS
    add_keyfile_to_luks "$luks_partition" "$keyfile"

    # Set secure permissions
    run "chmod 000 $keyfile"

    success "Embedded keyfile created"
}

# =============================================================================
# CRYPTTAB GENERATION
# =============================================================================

# Generate crypttab entry
generate_crypttab() {
    local mount_point="$1"
    local luks_partition="$2"

    section "Crypttab Configuration"

    local crypttab="${mount_point}/etc/crypttab"
    local luks_uuid
    luks_uuid=$(blkid -s UUID -o value "$luks_partition")

    info "Generating crypttab..."

    # Create crypttab with keyfile
    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would create crypttab"
        return 0
    fi

    cat > "$crypttab" << EOF
# <target name>  <source device>                        <key file>              <options>
${LUKS_MAPPER_NAME}    UUID=${luks_uuid}    ${KEYFILE_PATH}    luks,discard
EOF

    success "Crypttab generated"
    debug "Contents of crypttab:"
    [[ "$VERBOSE" == "true" ]] && cat "$crypttab"
}

# =============================================================================
# INITRAMFS HOOKS
# =============================================================================

# Configure mkinitcpio for LUKS
configure_mkinitcpio_luks() {
    local mount_point="$1"
    local mkinitcpio_conf="${mount_point}/etc/mkinitcpio.conf"

    section "Mkinitcpio Configuration"

    info "Configuring mkinitcpio for LUKS..."

    if [[ ! -f "$mkinitcpio_conf" ]]; then
        warn "mkinitcpio.conf not found at $mkinitcpio_conf"
        return 1
    fi

    # Backup original
    backup_file "$mkinitcpio_conf"

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would configure mkinitcpio for LUKS"
        return 0
    fi

    # Add keyfile to FILES
    if ! grep -q "crypto_keyfile.bin" "$mkinitcpio_conf"; then
        sed -i "s|^FILES=(|FILES=(${KEYFILE_PATH} |" "$mkinitcpio_conf"
    fi

    # Configure HOOKS for encryption
    # Required order: base udev autodetect modconf block encrypt filesystems keyboard fsck
    sed -i 's|^HOOKS=.*|HOOKS=(base udev autodetect modconf kms keyboard keymap consolefont block encrypt filesystems fsck)|' "$mkinitcpio_conf"

    success "Mkinitcpio configured for LUKS"
}

# =============================================================================
# GRUB ENCRYPTION CONFIGURATION
# =============================================================================

# Configure GRUB for encrypted root
configure_grub_luks() {
    local mount_point="$1"
    local luks_partition="$2"
    local grub_default="${mount_point}/etc/default/grub"

    section "GRUB Encryption Configuration"

    if [[ ! -f "$grub_default" ]]; then
        warn "GRUB default config not found"
        return 1
    fi

    local luks_uuid
    luks_uuid=$(blkid -s UUID -o value "$luks_partition")

    info "Configuring GRUB for encrypted root (UUID: $luks_uuid)..."

    backup_file "$grub_default"

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would configure GRUB for encryption"
        return 0
    fi

    # Set kernel parameters for encrypted root
    local cryptdevice="cryptdevice=UUID=${luks_uuid}:${LUKS_MAPPER_NAME}:allow-discards"
    local root_device="root=/dev/mapper/${LUKS_MAPPER_NAME}"

    # Update GRUB_CMDLINE_LINUX
    sed -i "s|^GRUB_CMDLINE_LINUX=.*|GRUB_CMDLINE_LINUX=\"${cryptdevice} ${root_device}\"|" "$grub_default"

    # Enable cryptodisk for GRUB
    if ! grep -q "GRUB_ENABLE_CRYPTODISK" "$grub_default"; then
        echo "GRUB_ENABLE_CRYPTODISK=y" >> "$grub_default"
    else
        sed -i 's|^#*GRUB_ENABLE_CRYPTODISK=.*|GRUB_ENABLE_CRYPTODISK=y|' "$grub_default"
    fi

    success "GRUB configured for encrypted root"
}

# =============================================================================
# VERIFICATION
# =============================================================================

# Verify LUKS setup
verify_luks() {
    local partition="$1"

    info "Verifying LUKS setup..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would verify LUKS setup"
        return 0
    fi

    # Check if LUKS header is present
    if cryptsetup isLuks "$partition"; then
        success "LUKS header verified on $partition"
    else
        error "No LUKS header found on $partition"
        return 1
    fi

    # Show LUKS info
    cryptsetup luksDump "$partition" | head -20
}

# =============================================================================
# EXPORTS
# =============================================================================
export LUKS_MAPPER_NAME LUKS_MAPPER_PATH KEYFILE_PATH
export LUKS_CIPHER LUKS_KEY_SIZE LUKS_HASH
export SDCARD_KEY_UUID
