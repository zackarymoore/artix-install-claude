#!/bin/bash
# lib/packages.sh - Package installation functions for Artix Linux
# Surface Go 2 Installation Project

# =============================================================================
# PACKAGE CONFIGURATION FILE PATH
# =============================================================================

PACKAGES_CONF="${SCRIPT_DIR}/config/packages.conf"

# =============================================================================
# PACKAGE LIST PARSING
# =============================================================================

# Parse packages from config file by category
get_packages_by_category() {
    local category="$1"
    local config_file="${2:-$PACKAGES_CONF}"

    if [[ ! -f "$config_file" ]]; then
        warn "Package config not found: $config_file"
        return 1
    fi

    # Extract packages under [category] section
    awk -v cat="[$category]" '
        $0 == cat { found=1; next }
        /^\[/ { found=0 }
        found && /^[^#]/ && NF { print $1 }
    ' "$config_file"
}

# Get all package categories from config
get_all_categories() {
    local config_file="${1:-$PACKAGES_CONF}"

    if [[ ! -f "$config_file" ]]; then
        return 1
    fi

    grep -oP '^\[\K[^\]]+' "$config_file"
}

# =============================================================================
# PACMAN PACKAGE INSTALLATION
# =============================================================================

# Install packages from Artix repos
install_pacman_packages() {
    local mount_point="${1:-/mnt}"
    shift
    local packages=("$@")

    if [[ ${#packages[@]} -eq 0 ]]; then
        warn "No packages specified"
        return 0
    fi

    info "Installing ${#packages[@]} packages via pacman..."
    debug "Packages: ${packages[*]}"

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would install: ${packages[*]}"
        return 0
    fi

    run_in_chroot "$mount_point" "pacman -S --noconfirm --needed ${packages[*]}"

    success "Packages installed"
}

# Install package category
install_category() {
    local mount_point="${1:-/mnt}"
    local category="$2"

    section "Installing: $category"

    local packages
    readarray -t packages < <(get_packages_by_category "$category")

    if [[ ${#packages[@]} -eq 0 ]]; then
        warn "No packages found for category: $category"
        return 0
    fi

    info "Found ${#packages[@]} packages in $category"
    install_pacman_packages "$mount_point" "${packages[@]}"
}

# Install all categories from config
install_all_categories() {
    local mount_point="${1:-/mnt}"

    section "Installing All Package Categories"

    local categories
    readarray -t categories < <(get_all_categories)

    for category in "${categories[@]}"; do
        install_category "$mount_point" "$category"
    done

    success "All package categories installed"
}

# =============================================================================
# AUR PACKAGE INSTALLATION
# =============================================================================

# Install AUR packages using paru
install_aur_packages() {
    local mount_point="${1:-/mnt}"
    local username="${2:-$USERNAME}"
    shift 2
    local packages=("$@")

    if [[ ${#packages[@]} -eq 0 ]]; then
        warn "No AUR packages specified"
        return 0
    fi

    info "Installing ${#packages[@]} AUR packages..."
    debug "AUR Packages: ${packages[*]}"

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would install AUR: ${packages[*]}"
        return 0
    fi

    # Install as regular user using paru
    run_in_chroot "$mount_point" "su - ${username} -c 'paru -S --noconfirm --needed ${packages[*]}'"

    success "AUR packages installed"
}

# Get AUR packages from config
get_aur_packages() {
    get_packages_by_category "aur"
}

# =============================================================================
# SPECIFIC PACKAGE GROUPS
# =============================================================================

# Install development tools
install_development() {
    local mount_point="${1:-/mnt}"

    section "Development Tools Installation"

    # Core development packages
    local dev_packages=(
        # Languages
        python
        python-pip
        rustup
        go
        nodejs
        npm
        # Version control
        git
        lazygit
        # Editors
        neovim
        # Build tools
        make
        cmake
        meson
        ninja
        # Debuggers
        gdb
        lldb
    )

    install_pacman_packages "$mount_point" "${dev_packages[@]}"

    # Initialize rustup
    run_in_chroot "$mount_point" "su - ${USERNAME} -c 'rustup default stable'"

    success "Development tools installed"
}

# Install Wayland desktop environment
install_wayland_desktop() {
    local mount_point="${1:-/mnt}"

    section "Wayland Desktop Installation"

    local wayland_packages=(
        # Core Wayland
        wayland
        wayland-protocols
        xorg-xwayland
        # Hyprland and tools
        hyprland
        hyprpaper
        hyprlock
        hypridle
        # Display manager
        ly
        # Terminal
        foot
        # Utilities
        grim
        slurp
        wl-clipboard
        # Audio
        pipewire
        pipewire-pulse
        pipewire-alsa
        wireplumber
        # Fonts
        ttf-dejavu
        ttf-liberation
        noto-fonts
        noto-fonts-emoji
    )

    install_pacman_packages "$mount_point" "${wayland_packages[@]}"

    # Enable ly display manager service
    run_in_chroot "$mount_point" "ln -sf /etc/runit/sv/ly /etc/runit/runsvdir/default/" || true

    success "Wayland desktop installed"
}

# Install audio stack
install_audio() {
    local mount_point="${1:-/mnt}"

    section "Audio Stack Installation"

    local audio_packages=(
        pipewire
        pipewire-alsa
        pipewire-pulse
        pipewire-jack
        wireplumber
        pavucontrol
        alsa-utils
    )

    install_pacman_packages "$mount_point" "${audio_packages[@]}"

    # Enable pipewire services for user
    info "PipeWire will auto-start via user service"

    success "Audio stack installed"
}

# Install terminal utilities
install_terminal_utils() {
    local mount_point="${1:-/mnt}"

    section "Terminal Utilities Installation"

    local term_packages=(
        # Shell
        zsh
        zsh-completions
        zsh-autosuggestions
        zsh-syntax-highlighting
        # Multiplexer
        zellij
        # File management
        vifm
        ranger
        # Search
        fzf
        ripgrep
        fd
        # Monitoring
        btop
        htop
        # Misc
        bat
        eza
        starship
        fastfetch
        tree
        jq
        yq
    )

    install_pacman_packages "$mount_point" "${term_packages[@]}"

    success "Terminal utilities installed"
}

# Install power management
install_power_management() {
    local mount_point="${1:-/mnt}"

    section "Power Management Installation"

    local power_packages=(
        tlp
        tlp-rdw
        tlp-runit
    )

    install_pacman_packages "$mount_point" "${power_packages[@]}"

    # Enable TLP service
    run_in_chroot "$mount_point" "ln -sf /etc/runit/sv/tlp /etc/runit/runsvdir/default/" || true

    success "Power management installed"
}

# =============================================================================
# POST-INSTALL AUR PACKAGES LIST
# =============================================================================

# Generate list of AUR packages for post-install
generate_aur_list() {
    local mount_point="${1:-/mnt}"
    local output_file="${mount_point}/home/${USERNAME}/post-install-aur.md"

    section "Generating AUR Package List"

    info "Creating AUR package list for post-install..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would generate AUR list"
        return 0
    fi

    cat > "$output_file" << 'EOF'
# Post-Install AUR Packages

These packages need to be installed from AUR after first boot.
Run these commands as your regular user:

## Essential AUR Packages

```bash
# Install paru first (if not already installed)
git clone https://aur.archlinux.org/paru-bin.git
cd paru-bin && makepkg -si && cd .. && rm -rf paru-bin

# AI Tools
paru -S claude-code-bin aichat-bin

# Terminal tools
paru -S bluetui zellij-bin

# Development
paru -S lazygit-bin

# Hyprland ecosystem
paru -S hyprlauncher-bin eww-wayland

# Utilities
paru -S pass-otp

# Communication
paru -S signal-cli scli-git

# Productivity
paru -S taskwarrior-tui vit
```

## Optional AUR Packages

```bash
# Crypto/Finance
paru -S cointop ticker

# Communication
paru -S telegram-tui-git iamb-bin

# Media
paru -S cava mpd-mpris

# Fonts
paru -S ttf-jetbrains-mono-nerd

# Misc
paru -S bottom-bin
```

## Notes

- Some packages may require manual configuration after installation
- Check each package's AUR page for dependencies and instructions
- Consider using `paru -S --needed` to skip already installed packages
EOF

    run_in_chroot "$mount_point" "chown ${USERNAME}:${USERNAME} /home/${USERNAME}/post-install-aur.md"

    success "AUR package list generated at /home/${USERNAME}/post-install-aur.md"
}

# =============================================================================
# PACKAGE VERIFICATION
# =============================================================================

# Verify critical packages are installed
verify_packages() {
    local mount_point="${1:-/mnt}"

    section "Package Verification"

    local critical_packages=(
        grub
        networkmanager
        neovim
        zsh
        hyprland
        foot
    )

    local missing=()

    for pkg in "${critical_packages[@]}"; do
        if ! run_in_chroot "$mount_point" "pacman -Qi $pkg" &>/dev/null; then
            missing+=("$pkg")
        fi
    done

    if [[ ${#missing[@]} -gt 0 ]]; then
        error "Missing critical packages: ${missing[*]}"
        return 1
    fi

    success "All critical packages verified"
}

# =============================================================================
# EXPORTS
# =============================================================================
export PACKAGES_CONF
export -f get_packages_by_category get_all_categories
export -f install_pacman_packages install_category install_all_categories
export -f install_aur_packages get_aur_packages
export -f install_development install_wayland_desktop install_audio
export -f install_terminal_utils install_power_management
export -f generate_aur_list verify_packages
