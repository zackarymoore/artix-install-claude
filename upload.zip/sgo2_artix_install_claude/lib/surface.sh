#!/bin/bash
# lib/surface.sh - Microsoft Surface-specific setup for Artix Linux
# Surface Go 2 Installation Project

# =============================================================================
# SURFACE KERNEL INSTALLATION
# =============================================================================

# Install linux-surface kernel
install_surface_kernel() {
    local mount_point="${1:-/mnt}"

    section "Linux-Surface Kernel Installation"

    info "Installing linux-surface kernel..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would install linux-surface kernel"
        return 0
    fi

    # Surface kernel packages
    local surface_packages=(
        linux-surface
        linux-surface-headers
        iptsd
    )

    run_in_chroot "$mount_point" "pacman -S --noconfirm ${surface_packages[*]}"

    success "Linux-surface kernel installed"
}

# =============================================================================
# SURFACE FIRMWARE
# =============================================================================

# Install Surface firmware
install_surface_firmware() {
    local mount_point="${1:-/mnt}"

    section "Surface Firmware Installation"

    info "Checking for Surface firmware requirements..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would check/install Surface firmware"
        return 0
    fi

    # The linux-surface kernel usually includes necessary firmware
    # Additional firmware may be needed for specific devices

    # Check if running on Surface hardware
    if grep -qi "surface" /sys/devices/virtual/dmi/id/product_name 2>/dev/null; then
        info "Running on Surface hardware"

        # Install additional firmware if available
        run_in_chroot "$mount_point" "pacman -S --noconfirm --needed linux-firmware" || true
    fi

    success "Firmware check complete"
}

# =============================================================================
# TOUCHSCREEN / IPTSD
# =============================================================================

# Configure IPTSD for touchscreen
configure_iptsd() {
    local mount_point="${1:-/mnt}"

    section "IPTSD Touchscreen Configuration"

    info "Configuring IPTSD touchscreen daemon..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would configure IPTSD"
        return 0
    fi

    # Create IPTSD config directory
    ensure_dir "${mount_point}/etc/iptsd"

    # Create IPTSD configuration
    cat > "${mount_point}/etc/iptsd/iptsd.conf" << 'EOF'
# IPTSD Configuration for Surface Go 2
# https://github.com/linux-surface/iptsd

[Config]
# Invert the touchscreen axes if needed
InvertX = false
InvertY = false

[Touch]
# Disable palm rejection if having issues
DisablePalmRejection = false

[Stylus]
# Stylus configuration
Enable = true
EOF

    # Create runit service for iptsd
    local iptsd_sv="${mount_point}/etc/runit/sv/iptsd"
    ensure_dir "$iptsd_sv"

    cat > "${iptsd_sv}/run" << 'EOF'
#!/bin/sh
exec 2>&1
exec iptsd
EOF

    chmod +x "${iptsd_sv}/run"

    # Enable iptsd service
    run_in_chroot "$mount_point" "ln -sf /etc/runit/sv/iptsd /etc/runit/runsvdir/default/" || true

    success "IPTSD configured"
}

# =============================================================================
# POWER MANAGEMENT FOR SURFACE
# =============================================================================

# Configure TLP for Surface
configure_tlp_surface() {
    local mount_point="${1:-/mnt}"
    local tlp_conf="${mount_point}/etc/tlp.conf"

    section "Surface Power Management"

    info "Configuring TLP for Surface Go 2..."

    if [[ ! -f "$tlp_conf" ]]; then
        warn "TLP configuration not found, skipping"
        return 0
    fi

    backup_file "$tlp_conf"

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would configure TLP for Surface"
        return 0
    fi

    # Create Surface-optimized TLP config
    cat > "$tlp_conf" << 'EOF'
# TLP Configuration for Surface Go 2
# Optimized for battery life on low-power device

# Operation Mode
TLP_ENABLE=1
TLP_DEFAULT_MODE=BAT

# CPU Settings
# Intel Pentium Gold 4425Y - optimize for efficiency
CPU_SCALING_GOVERNOR_ON_AC=performance
CPU_SCALING_GOVERNOR_ON_BAT=powersave

CPU_ENERGY_PERF_POLICY_ON_AC=balance_performance
CPU_ENERGY_PERF_POLICY_ON_BAT=power

CPU_MIN_PERF_ON_AC=0
CPU_MAX_PERF_ON_AC=100
CPU_MIN_PERF_ON_BAT=0
CPU_MAX_PERF_ON_BAT=60

CPU_BOOST_ON_AC=1
CPU_BOOST_ON_BAT=0

CPU_HWP_DYN_BOOST_ON_AC=1
CPU_HWP_DYN_BOOST_ON_BAT=0

# SATA/AHCI
SATA_LINKPWR_ON_AC="med_power_with_dipm max_performance"
SATA_LINKPWR_ON_BAT="med_power_with_dipm min_power"

# PCIe ASPM
PCIE_ASPM_ON_AC=default
PCIE_ASPM_ON_BAT=powersupersave

# WiFi Power Management
WIFI_PWR_ON_AC=off
WIFI_PWR_ON_BAT=on

# Audio Power Saving
SOUND_POWER_SAVE_ON_AC=0
SOUND_POWER_SAVE_ON_BAT=1

# Runtime PM
RUNTIME_PM_ON_AC=on
RUNTIME_PM_ON_BAT=auto

# USB Autosuspend
USB_AUTOSUSPEND=1
USB_EXCLUDE_BTUSB=1
USB_EXCLUDE_PHONE=1

# Battery Care (if supported)
START_CHARGE_THRESH_BAT0=75
STOP_CHARGE_THRESH_BAT0=80

# NMI Watchdog
NMI_WATCHDOG=0
EOF

    success "TLP configured for Surface"
}

# =============================================================================
# SURFACE-SPECIFIC KERNEL PARAMETERS
# =============================================================================

# Configure kernel parameters for Surface
configure_surface_kernel_params() {
    local mount_point="${1:-/mnt}"
    local grub_default="${mount_point}/etc/default/grub"

    section "Surface Kernel Parameters"

    info "Adding Surface-specific kernel parameters..."

    if [[ ! -f "$grub_default" ]]; then
        warn "GRUB config not found"
        return 1
    fi

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would configure Surface kernel parameters"
        return 0
    fi

    # Surface-specific kernel parameters
    local surface_params="i915.enable_psr=0 i915.enable_fbc=1"

    # Add to existing GRUB_CMDLINE_LINUX
    local current_params
    current_params=$(grep "^GRUB_CMDLINE_LINUX=" "$grub_default" | cut -d'"' -f2)

    # Only add if not already present
    if [[ ! "$current_params" =~ "i915" ]]; then
        sed -i "s|^GRUB_CMDLINE_LINUX=\"|GRUB_CMDLINE_LINUX=\"${surface_params} |" "$grub_default"
    fi

    success "Surface kernel parameters configured"
}

# =============================================================================
# TYPE COVER / KEYBOARD
# =============================================================================

# Configure Type Cover keyboard
configure_type_cover() {
    local mount_point="${1:-/mnt}"

    section "Type Cover Configuration"

    info "Configuring Type Cover keyboard..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would configure Type Cover"
        return 0
    fi

    # Type Cover should work out of the box with linux-surface
    # Add any custom keybindings if needed

    # Create libinput quirks for Surface Type Cover
    ensure_dir "${mount_point}/etc/libinput"

    cat > "${mount_point}/etc/libinput/local-overrides.quirks" << 'EOF'
# Surface Type Cover quirks

[Microsoft Surface Type Cover]
MatchUdevType=keyboard
MatchName=*Type Cover*
AttrKeyboardIntegration=internal

[Microsoft Surface Type Cover Touchpad]
MatchUdevType=touchpad
MatchName=*Type Cover*
AttrPressureRange=10:8
EOF

    success "Type Cover configured"
}

# =============================================================================
# DISPLAY / BRIGHTNESS
# =============================================================================

# Configure display settings for Surface
configure_surface_display() {
    local mount_point="${1:-/mnt}"

    section "Surface Display Configuration"

    info "Configuring display settings..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would configure display"
        return 0
    fi

    # Add udev rule for backlight control
    ensure_dir "${mount_point}/etc/udev/rules.d"

    cat > "${mount_point}/etc/udev/rules.d/90-backlight.rules" << 'EOF'
# Allow users in video group to control backlight
ACTION=="add", SUBSYSTEM=="backlight", RUN+="/bin/chgrp video $sys$devpath/brightness", RUN+="/bin/chmod g+w $sys$devpath/brightness"
EOF

    success "Display configured"
}

# =============================================================================
# CAMERAS
# =============================================================================

# Configure Surface cameras (IPU3/IPU6)
configure_surface_cameras() {
    local mount_point="${1:-/mnt}"

    section "Surface Camera Configuration"

    info "Configuring Surface cameras..."

    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${MAGENTA}[DRY-RUN]${NC} Would configure cameras"
        return 0
    fi

    # Surface Go 2 uses Intel IPU3 cameras
    # They require specific firmware and libcamera

    # Install camera packages if available
    run_in_chroot "$mount_point" "pacman -S --noconfirm --needed libcamera v4l-utils" || true

    info "Camera support may require additional configuration post-install"

    success "Camera setup complete"
}

# =============================================================================
# COMPLETE SURFACE SETUP
# =============================================================================

# Run all Surface-specific setup
setup_surface() {
    local mount_point="${1:-/mnt}"

    section "Complete Surface Setup"

    info "Running complete Surface Go 2 setup..."

    # Install Surface kernel
    install_surface_kernel "$mount_point"

    # Install firmware
    install_surface_firmware "$mount_point"

    # Configure touchscreen
    configure_iptsd "$mount_point"

    # Configure power management
    configure_tlp_surface "$mount_point"

    # Configure kernel parameters
    configure_surface_kernel_params "$mount_point"

    # Configure Type Cover
    configure_type_cover "$mount_point"

    # Configure display
    configure_surface_display "$mount_point"

    # Configure cameras
    configure_surface_cameras "$mount_point"

    success "Surface setup complete"
}

# =============================================================================
# EXPORTS
# =============================================================================
export -f install_surface_kernel install_surface_firmware
export -f configure_iptsd configure_tlp_surface
export -f configure_surface_kernel_params configure_type_cover
export -f configure_surface_display configure_surface_cameras
export -f setup_surface
