# Artix Linux Install & Rice - Surface Go

## Introduction
This document is a planning document for a series of interactive scripts that will install Artix Linux base packages, the linux-surface kernel, and then needs to import a complete development environment after first boot. The development environment will be interactively installed by the user after the first boot so the installation must include drivers for bluetooth and networking as well as configuration utilities, the base dev environment will be installed via ansible and future code projects will be built out by nix. this project will include creating all files, scripts, and configuration files needed to go from an iso already on a boot drive, to a complete, functional, development laptop. The main usage of this machine will be research, communications, and writing code. The code written will primarily be ran on a development server but the tools to run code locally will be installed and configured to allow this to be optional. This machine will be used for local development (python, rust, go, node, etc.) as well as server side development (html, css, js, php, etc.).

## Hardware 
- Microsoft Surface Go 2
  - 8th gen intel pentium gold 4425y
  - 4gb lpddr3 ram
  - 65gb emmc storage (boot, root, home, etc.)
  - 256gb sd card storage (file storage and encrypted file storage)

## Standards 
- the environment must be completely reproducible with as little manual intervention as possible
- a complete reinstall and restoration should be as simple and automatic as possible
- a system to test updates and allow for graceful rollbacks if needed should be in place
- software sources need to be considered, we want secure code, to be able to install the versions we need for compatibility and development environments, and to not compile software unless it is needed or the better option
- resources on the destination computer are limited so we need to examine all software selections and make sure that there are not better options for this constraint
- we want to eliminate excess dependencies, before we finalize this project we will need to review the total package count, install size, and any other metrics to determine if there is room for improvement
- automations for system maintenance tasks such as clearing temp files, clearing cache(s), removing old kernels, etc.
- documentation will need to be created that includes each piece of included software, the location of the config files, and a section that documents any relevant commands, hotkeys, variables, etc. we have set in the process of this project

## Deliverables
- installation script(s)
- setup script(s)
- software configuration file(s)
- system documentation
- additional feature/automation scripts, configurations, etc.

## Base System
| role | software | source | config file(s) |
| ---- | -------- | ------ | -------------- |
| os | artix linux | artixlinux.org | n/a |
| kernel | linux-surface | aur | n/a |
| init | runit | pacman | n/a |
| microcode | intel-ucode | pacman | n/a |
| networking | networkmanager, nmtui | pacman | |
| bluetooth | bluez, bluetui | pacman | |

### Base Install Requirements
- full disk encryption on emmc 

## Development environment

### Base (TTY: basic usage, emergency recovery)
| role | software | source | config file(s) | notes |
| ---- | -------- | ------ | -------------- | ----- |
| shell | zsh (tty)| | | |
| editor | neovim | | | |
| file manager | vifm | | | |
| multiplexer | zellij | | | |
| power management | tlp, tlp-rdw AND/OR auto-cpufreq | | | these will need tested and compared in various configs before a system reinstall using outcomes | 
| audio | pipewire, wireplumber | | | |
| aur helper | | | | |
| keystore | pass (offline), gopass (online) | | | |
| otp | otti | | | |
| search | fzf | | | |
| music | mpd, rmpc | | | |
| email | aerc (tui), himalaya (cli/automations) | | | |
| version control | git, lazygit | | | |
| downloads | curl, wget, rtorrent, nzbget | | | |
| ai-google | gemini | | | |
| ai-chatgpt | codex | | | |
| ai-anthropic | claude | | | |
| ai-local-misc | aichat | | | |
| ai-prompts | fabric | | | |
| wallet | wagyu | | | |
| crypto | cointop | | | |
| market | ticker | | | |
| spreadsheet | sc-im | | | |
| pager | less (docs), w3m (md, html, etc.) | | | |
| python | python3, pip, venv | | | |
| rust | rustup | | | |
| nodejs | npm | | | |
| golang | go | | | |
| version manager | asdf (plugins for python, rust, nodejs, and golang) | | | |
| terminal selector | pipedial | | | | 
| task management | taskwarrior, vit (taskwarrior-tui for more features if needed) | | | |
| messenger-matrix | iamb | | | |
| messenger-signal | signal-cli, scli | | | |
| messenger-telegram | telegram-tui | | | |
| messenger-irc | tiny | | | |
| messenger-slack | weechat, wee-slack | | | |
| messenger-rcs | tbd | | | |
| feed-rss | russ | | | |
| feed-hackernews | haxor-news | | | |
| social-mastodon | tut, madonctl | | | |
| social-bluesky | bsky | | | |
| social-twitter | twurl | | | |
| social-truthsocial | truthbrush | | | |
| calendar | khal | | | |
| contacts | khard | | | |
| caldav sync | vdirsyncer | | | |
| time tracking | timewarrior | | | |
| notebook | nb | | | | 
| journal | jrnl | | | |
| personal-wiki | zk | | | |
| resource monitor | bottom | | | |
| system information | fastfetch | | | |
| dictionary | wordnet (general), dict (customs) | | | |
| text to speech | piper (ai/complex), espeak-ng (notifications) | | | |
| translations | translate-shell | | | |
| automation | ansible | | | |
| build system | nix (not nixos) | | | |
| containers | podman, podman-compose | | | |
| vpn client | wireguard | | | |
| packet capture | tshark, termshark | | | |
| network scanner | nmap, netscanner | | | |

### Main (GUI: typical environment)
| role | software | source | config file(s) | notes |
| ---- | -------- | ------ | -------------- | ----- |
| shell | nushell | | | | 
| dictionary daemon | dictd | | | |
| display manager | ly | | | |
| display server | wayland | | | |
| window manager | hyprland | | | |
| notifications | end-rs | | | |
| lock screen | hyprlock | | | |
| wallpaper | hyprpaper | | | |
| browser | chromium, firefox | | | |
| screenshots | grim, slurp, swappy | | | |
| pdf reader | zathura | | | |
| file manager | vifm: sixel, show-sixel | | | |
| terminal | foot | | | |
| visualizer | cava | | | |
| clipboard | clipvault | | | |
| video player/image viewer | mpv, ffmpeg | | | |
| launcher | hyprlauncher | | | |
| widgets | eww | | | |

## Rice
- color scheme: selenized dark

- wallpaper: wallpaper.jpg 

- hyprpaper
  - wallpaper

- hyprland
  - gestures
    - 3 finger up launch eww dashboard
    - 3 finger down closes current
    - 3 finger horizontal swaps workspace
    - pinch out fullscreens current
    - pinch in un-fullscreens current 
  - color scheme

- hyprlock
  - match hyprpaper wallpaper
  - color scheme

- hyprlauncher
  - monitor 1920x1280@60, 0x0, 1 
  - color scheme

- eww
  - bar
  - power menu
  - calendar
  - dashboard
    - tasks
    - calendar
    - notifications
    - now playing
    - inboxes
      - email
      - messaging

## To-Do (we'll collaborate on these after all other steps are complete)

### GUI
- hyprlauncher
  - local search for hyprlauncher
  - calc for hyprlauncher
  - project management for hyprlauncher (launches applications in the correct folder/environment/project)
  - translate for hyprlauncher
  - web search for hyprlauncher (localhost AND self-hosted)
  - taskwarrior in hyprlauncher
  - timewarrior in hyprlauncher
- neovim
  - lazyvim

### Misc.
- zsh & nushell: sync compatible settings, aliases, paths, etc.


