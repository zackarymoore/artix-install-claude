#!/bin/bash
# post-install.sh - Post-installation setup script
#
# Run this script after first boot to complete the system setup.
# This script should be run as your regular user (not root).
#
# Usage:
#   ./post-install.sh           # Full post-install setup
#   ./post-install.sh --aur     # Only install AUR packages
#   ./post-install.sh --dotfiles # Only deploy dotfiles

set -euo pipefail

# =============================================================================
# COLORS AND UTILITIES
# =============================================================================
readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly CYAN='\033[0;36m'
readonly NC='\033[0m'

info()    { echo -e "${CYAN}[INFO]${NC} $*"; }
success() { echo -e "${GREEN}[SUCCESS]${NC} $*"; }
warn()    { echo -e "${YELLOW}[WARNING]${NC} $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*" >&2; }

section() {
    echo
    echo -e "${CYAN}════════════════════════════════════════════════════════════════${NC}"
    echo -e "  $1"
    echo -e "${CYAN}════════════════════════════════════════════════════════════════${NC}"
    echo
}

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

# =============================================================================
# CHECKS
# =============================================================================

check_not_root() {
    if [[ $EUID -eq 0 ]]; then
        error "This script should NOT be run as root"
        exit 1
    fi
}

check_internet() {
    info "Checking internet connection..."
    if ! ping -c 1 -W 5 artixlinux.org &>/dev/null; then
        error "No internet connection"
        exit 1
    fi
    success "Internet connection OK"
}

# =============================================================================
# AUR HELPER INSTALLATION
# =============================================================================

install_paru() {
    section "AUR Helper Installation"

    if command -v paru &>/dev/null; then
        success "Paru is already installed"
        return 0
    fi

    info "Installing paru AUR helper..."

    local tmp_dir
    tmp_dir=$(mktemp -d)
    cd "$tmp_dir"

    git clone https://aur.archlinux.org/paru-bin.git
    cd paru-bin
    makepkg -si --noconfirm

    cd /
    rm -rf "$tmp_dir"

    success "Paru installed"
}

# =============================================================================
# AUR PACKAGES
# =============================================================================

install_aur_packages() {
    section "AUR Package Installation"

    # Essential AUR packages
    local essential_aur=(
        # Terminal tools
        lazygit-bin
        bluetui

        # Hyprland ecosystem
        hyprlauncher-bin
        eww-wayland

        # Development
        asdf-vm

        # Productivity
        taskwarrior-tui
        vit
    )

    info "Installing essential AUR packages..."
    paru -S --noconfirm --needed "${essential_aur[@]}" || warn "Some packages may have failed"

    success "Essential AUR packages installed"
}

install_optional_aur() {
    section "Optional AUR Packages"

    echo "Optional packages available:"
    echo "  1. AI Tools (claude-code-bin, aichat-bin)"
    echo "  2. Communication (signal-cli, scli-git, iamb-bin)"
    echo "  3. Media (cava, mpd, rmpc)"
    echo "  4. Crypto/Finance (cointop, ticker)"
    echo "  5. All optional packages"
    echo "  6. Skip optional packages"
    echo

    read -rp "Select option [6]: " choice
    choice=${choice:-6}

    case "$choice" in
        1)
            paru -S --noconfirm --needed claude-code-bin aichat-bin || true
            ;;
        2)
            paru -S --noconfirm --needed signal-cli scli-git iamb-bin || true
            ;;
        3)
            paru -S --noconfirm --needed cava mpd rmpc || true
            ;;
        4)
            paru -S --noconfirm --needed cointop ticker || true
            ;;
        5)
            local optional_aur=(
                claude-code-bin
                aichat-bin
                signal-cli
                scli-git
                iamb-bin
                cava
                mpd
                rmpc
                cointop
                ticker
                bottom-bin
                pass-otp
                translate-shell
                nb
                jrnl
                zk
                tut
            )
            paru -S --noconfirm --needed "${optional_aur[@]}" || warn "Some packages may have failed"
            ;;
        *)
            info "Skipping optional packages"
            ;;
    esac
}

# =============================================================================
# RUST TOOLCHAIN
# =============================================================================

setup_rust() {
    section "Rust Toolchain Setup"

    if command -v rustc &>/dev/null; then
        success "Rust is already installed"
        return 0
    fi

    info "Setting up Rust toolchain..."

    rustup default stable
    rustup component add rust-analyzer

    success "Rust toolchain configured"
}

# =============================================================================
# ASDF VERSION MANAGER
# =============================================================================

setup_asdf() {
    section "ASDF Version Manager Setup"

    if [[ ! -d "$HOME/.asdf" ]]; then
        info "Installing asdf..."
        git clone https://github.com/asdf-vm/asdf.git ~/.asdf --branch v0.14.0
    fi

    # Source asdf
    export ASDF_DIR="$HOME/.asdf"
    # shellcheck source=/dev/null
    source "$HOME/.asdf/asdf.sh"

    # Install plugins
    local plugins=(python nodejs golang)

    for plugin in "${plugins[@]}"; do
        if ! asdf plugin list | grep -q "$plugin"; then
            info "Adding asdf plugin: $plugin"
            asdf plugin add "$plugin" || true
        fi
    done

    success "ASDF configured"
}

# =============================================================================
# DOTFILES
# =============================================================================

deploy_dotfiles() {
    section "Dotfiles Deployment"

    local dotfiles_src="${SCRIPT_DIR}/dotfiles"

    if [[ ! -d "$dotfiles_src" ]]; then
        warn "Dotfiles directory not found: $dotfiles_src"
        return 0
    fi

    info "Deploying dotfiles..."

    # Ensure config directory exists
    mkdir -p "$HOME/.config"

    # Copy config directories
    for dir in "$dotfiles_src"/*/; do
        if [[ -d "$dir" ]]; then
            local dir_name
            dir_name=$(basename "$dir")
            info "Deploying $dir_name..."

            # Backup existing config
            if [[ -d "$HOME/.config/$dir_name" ]]; then
                mv "$HOME/.config/$dir_name" "$HOME/.config/${dir_name}.backup.$(date +%Y%m%d)"
            fi

            cp -r "$dir" "$HOME/.config/"
        fi
    done

    # Copy root-level dotfiles
    for file in "$dotfiles_src"/.*; do
        if [[ -f "$file" ]]; then
            local file_name
            file_name=$(basename "$file")
            info "Deploying $file_name..."

            # Backup existing file
            if [[ -f "$HOME/$file_name" ]]; then
                mv "$HOME/$file_name" "$HOME/${file_name}.backup.$(date +%Y%m%d)"
            fi

            cp "$file" "$HOME/"
        fi
    done

    success "Dotfiles deployed"
}

# =============================================================================
# PIPEWIRE USER SERVICES
# =============================================================================

setup_audio() {
    section "Audio Setup"

    info "PipeWire should auto-start on login"

    # Create user systemd-like directories for runit user services
    mkdir -p "$HOME/.config/sv"

    success "Audio setup complete"
}

# =============================================================================
# GPG AND PASS
# =============================================================================

setup_gpg() {
    section "GPG and Pass Setup"

    if [[ -d "$HOME/.gnupg" ]]; then
        info "GPG directory already exists"
        return 0
    fi

    info "Initializing GPG..."

    # Create GPG directory with correct permissions
    mkdir -p "$HOME/.gnupg"
    chmod 700 "$HOME/.gnupg"

    echo
    echo "To complete GPG setup:"
    echo "  1. Generate a key: gpg --full-generate-key"
    echo "  2. Initialize pass: pass init <your-gpg-id>"
    echo

    success "GPG directory created"
}

# =============================================================================
# DISPLAY SUMMARY
# =============================================================================

show_summary() {
    section "Post-Install Complete!"

    echo "Your system is now configured with:"
    echo
    echo "  - Paru AUR helper"
    echo "  - Essential AUR packages"
    echo "  - Rust toolchain"
    echo "  - ASDF version manager"
    echo "  - Configuration files"
    echo
    echo "Next steps:"
    echo "  1. Log out and back in for shell changes"
    echo "  2. Run 'Hyprland' to start the desktop"
    echo "  3. Configure GPG: gpg --full-generate-key"
    echo "  4. Initialize pass: pass init <gpg-id>"
    echo "  5. Review ~/.config/ for customization"
    echo
    echo "Useful commands:"
    echo "  paru -Syu          # Update all packages"
    echo "  paru -Ss <pkg>     # Search packages"
    echo "  btop               # System monitor"
    echo "  lazygit            # Git TUI"
    echo
}

# =============================================================================
# ARGUMENT PARSING
# =============================================================================

AUR_ONLY=false
DOTFILES_ONLY=false

while [[ $# -gt 0 ]]; do
    case "$1" in
        --aur)
            AUR_ONLY=true
            ;;
        --dotfiles)
            DOTFILES_ONLY=true
            ;;
        --help|-h)
            echo "Usage: $0 [--aur|--dotfiles|--help]"
            exit 0
            ;;
        *)
            error "Unknown option: $1"
            exit 1
            ;;
    esac
    shift
done

# =============================================================================
# MAIN
# =============================================================================

main() {
    section "Post-Installation Setup"

    check_not_root
    check_internet

    if [[ "$AUR_ONLY" == "true" ]]; then
        install_paru
        install_aur_packages
        install_optional_aur
        exit 0
    fi

    if [[ "$DOTFILES_ONLY" == "true" ]]; then
        deploy_dotfiles
        exit 0
    fi

    # Full setup
    install_paru
    install_aur_packages
    install_optional_aur
    setup_rust
    setup_asdf
    deploy_dotfiles
    setup_audio
    setup_gpg

    show_summary
}

main "$@"
